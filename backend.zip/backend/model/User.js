import mongoose from 'mongoose';

const userSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: false,
      unique: true,
      sparse: true,
    },
    phone: {
      type: String,
      required: true,
      unique: true,
    },
    role: {
      type: String,
      enum: ['user', 'worker', 'admin'],
      default: 'user',
    },
    // You can add more fields as needed, e.g., password, address, etc.
  },
  {
    timestamps: true,
  }
);

const User = mongoose.model('User', userSchema);

export default User;
