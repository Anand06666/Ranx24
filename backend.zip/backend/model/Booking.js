import mongoose from 'mongoose';

const BookingSchema = mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    worker: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'Worker',
    },
    category: {
      type: String,
      required: true,
    },
    service: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: false,
    },
    bookingType: {
      type: String,
      enum: ['full-day', 'half-day', 'multiple-days'],
      default: 'full-day',
    },
    days: {
      type: Number,
      default: 1,
    },
    startDate: {
      type: Date
    },
    endDate: {
      type: Date
    },
    bookingDate: {
      type: Date,
      required: true,
    },
    bookingTime: {
      type: String, // e.g., "10:00 AM"
      required: true,
    },
    address: {
      street: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      zipCode: { type: String, required: true },
    },
    totalPrice: {
      type: Number,
      required: true,
    },
    couponApplied: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Coupon'
    },
    couponCode: {
      type: String
    },
    couponDiscount: {
      type: Number,
      default: 0
    },
    coinsUsed: {
      type: Number,
      default: 0
    },
    coinDiscount: {
      type: Number,
      default: 0
    },
    cashbackEarned: {
      type: Number,
      default: 0
    },
    finalPrice: {
      type: Number,
      required: true
    },
    paymentMethod: {
      type: String,
    },
    price: {
      type: Number,
      required: true,
      default: 0,
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'accepted', 'in-progress', 'completed', 'cancelled', 'rejected'],
      default: 'pending',
    },
    paymentStatus: {
      type: String,
      required: true,
      enum: ['pending', 'paid', 'refunded'],
      default: 'pending',
    },
    paymentId: {
      type: String,
    },
    // For YC Coins reward tracking
    ycCoinsEarned: {
      type: Number,
      default: 0,
    },
    isYcCoinsCredited: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for common queries
BookingSchema.index({ user: 1, createdAt: -1 }); // User's bookings sorted by date
BookingSchema.index({ worker: 1, createdAt: -1 }); // Worker's bookings sorted by date
BookingSchema.index({ status: 1, createdAt: -1 }); // Filter by status, sort by date
BookingSchema.index({ user: 1, status: 1 }); // User's bookings by status
BookingSchema.index({ worker: 1, status: 1 }); // Worker's bookings by status
BookingSchema.index({ paymentStatus: 1 }); // Payment status lookup
BookingSchema.index({ bookingDate: 1 }); // Bookings by date

const Booking = mongoose.model('Booking', BookingSchema);

export default Booking;