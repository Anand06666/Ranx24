import path from 'path';
import fs from 'fs';
import Category from '../model/Category.js';
import cacheService, { cacheKeys, cacheTTL } from '../utils/cacheService.js';

// @desc    Get all categories
// @route   GET /api/categories
// @access  Public
export const getCategories = async (req, res) => {
  try {
    // Try to get from cache
    const categories = await cacheService.wrap(
      cacheKeys.categories(),
      async () => await Category.find({}),
      cacheTTL.long // Cache for 30 minutes
    );

    res.json(categories);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Create a category
// @route   POST /api/categories
// @access  Admin
export const createCategory = async (req, res) => {
  const { name } = req.body;
  let imagePath = '';

  if (req.files && req.files.categoryImage) {
    imagePath = req.files.categoryImage[0].path;
  }

  try {
    const categoryExists = await Category.findOne({ name });

    if (categoryExists) {
      // If category exists and an image was uploaded, delete the uploaded image
      if (imagePath) {
        // Assuming imagePath is relative to the project root or a known uploads folder
        // You might need to adjust this path based on your server setup
        const fullPath = path.join(process.cwd(), imagePath);
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
        }
      }
      return res.status(400).json({ message: 'Category already exists' });
    }

    const category = new Category({
      name,
      image: imagePath, // Save the image path
    });

    const createdCategory = await category.save();

    // Invalidate cache
    cacheService.delete(cacheKeys.categories());

    res.status(201).json(createdCategory);
  } catch (error) {
    console.error('Error creating category:', error); // Log the error for debugging
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Update a category
// @route   PUT /api/categories/:id
// @access  Admin
export const updateCategory = async (req, res) => {
  const { name } = req.body;
  let newImagePath = '';

  if (req.files && req.files.categoryImage) {
    newImagePath = req.files.categoryImage[0].path;
  }

  try {
    const category = await Category.findById(req.params.id);

    if (category) {
      // Update name if provided
      if (name) {
        category.name = name;
      }

      // Handle image update
      if (newImagePath) {
        // If there's an old image, delete it
        if (category.image) {
          const oldImagePath = path.join(process.cwd(), category.image);
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
          }
        }
        category.image = newImagePath; // Set new image path
      }

      const updatedCategory = await category.save();
      res.json(updatedCategory);
    } else {
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (error) {
    console.error('Error updating category:', error); // Log the error for debugging
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Delete a category
// @route   DELETE /api/categories/:id
// @access  Admin
export const deleteCategory = async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);

    if (category) {
      await Category.deleteOne({ _id: req.params.id });
      res.json({ message: 'Category removed' });
    } else {
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

export const getCategoryById = async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);

    if (category) {
      res.json(category);
    } else {
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (error) {
    console.error('Error fetching category by ID:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Create a sub-category
// @route   POST /api/categories/:id/subcategories
// @access  Admin
export const createSubCategory = async (req, res) => {
  const { name } = req.body;
  let imagePath = '';

  if (req.files && req.files.categoryImage) {
    imagePath = req.files.categoryImage[0].path;
  }

  try {
    const category = await Category.findById(req.params.id);

    if (category) {
      const subCategoryExists = category.subCategories.find(
        (sub) => sub.name === name
      );

      if (subCategoryExists) {
        if (imagePath) {
          const fullPath = path.join(process.cwd(), imagePath);
          if (fs.existsSync(fullPath)) {
            fs.unlinkSync(fullPath);
          }
        }
        return res.status(400).json({ message: 'Sub-category already exists' });
      }

      const subCategory = { name, image: imagePath };
      category.subCategories.push(subCategory);
      await category.save();
      res.status(201).json(category);
    } else {
      if (imagePath) {
        const fullPath = path.join(process.cwd(), imagePath);
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
        }
      }
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (error) {
    if (imagePath) {
      const fullPath = path.join(process.cwd(), imagePath);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
    }
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Update a sub-category
// @route   PUT /api/categories/:id/subcategories/:subId
// @access  Admin
export const updateSubCategory = async (req, res) => {
  const { name } = req.body;
  let newImagePath = '';

  if (req.files && req.files.categoryImage) {
    newImagePath = req.files.categoryImage[0].path;
  }

  try {
    const category = await Category.findById(req.params.id);

    if (category) {
      const subCategory = category.subCategories.id(req.params.subId);

      if (subCategory) {
        if (name) {
          subCategory.name = name;
        }

        if (newImagePath) {
          if (subCategory.image) {
            const oldImagePath = path.join(process.cwd(), subCategory.image);
            if (fs.existsSync(oldImagePath)) {
              fs.unlinkSync(oldImagePath);
            }
          }
          subCategory.image = newImagePath;
        }

        await category.save();
        res.json(category);
      } else {
        if (newImagePath) {
          const fullPath = path.join(process.cwd(), newImagePath);
          if (fs.existsSync(fullPath)) {
            fs.unlinkSync(fullPath);
          }
        }
        res.status(404).json({ message: 'Sub-category not found' });
      }
    } else {
      if (newImagePath) {
        const fullPath = path.join(process.cwd(), newImagePath);
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
        }
      }
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (error) {
    if (newImagePath) {
      const fullPath = path.join(process.cwd(), newImagePath);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
    }
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Delete a sub-category
// @route   DELETE /api/categories/:id/subcategories/:subId
// @access  Admin
export const deleteSubCategory = async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);

    if (category) {
      const subCategory = category.subCategories.id(req.params.subId);

      if (subCategory) {
        await subCategory.deleteOne();
        await category.save();
        res.json(category);
      } else {
        res.status(404).json({ message: 'Sub-category not found' });
      }
    } else {
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

