import Booking from '../model/Booking.js';
import User from '../model/User.js';
import Worker from '../model/Worker.js';
import Coupon from '../model/Coupon.js';
import CouponUsage from '../model/CouponUsage.js';
import CoinConfig from '../model/CoinConfig.js';
import { ensureWallet, creditYCCoins } from './userwalletController.js';
import { deductCoins, awardCashback } from './coinsController.js';
import { getPaginationParams, createPaginatedResponse } from '../utils/paginationHelper.js';



// @desc    Create a new booking
// @route   POST /api/bookings
// @access  Private (User)
export const createBooking = async (req, res) => {
  const {
    workerId, category, service, description, bookingDate, bookingTime, address,
    price, bookingType, days, startDate, endDate, paymentStatus, paymentId,
    couponCode, coinsUsed
  } = req.body;

  // Basic validation
  if (!workerId || !category || !service || !bookingDate || !bookingTime || !address || !price) {
    return res.status(400).json({ message: 'Please enter all required fields for the booking.' });
  }

  try {
    // Check if worker exists
    const worker = await Worker.findById(workerId);
    if (!worker) {
      return res.status(404).json({ message: 'Worker not found.' });
    }

    let totalPrice = price;
    let couponDiscount = 0;
    let coinDiscount = 0;
    let couponId = null;
    let actualCouponCode = null;

    // ========== COUPON VALIDATION ==========
    if (couponCode) {
      const coupon = await Coupon.findOne({ code: couponCode.toUpperCase() });

      if (!coupon) {
        return res.status(400).json({ message: 'Invalid coupon code' });
      }

      // Validate coupon
      if (!coupon.isActive) {
        return res.status(400).json({ message: 'Coupon is not active' });
      }

      const now = new Date();
      if (now < coupon.validFrom || now > coupon.validUntil) {
        return res.status(400).json({ message: 'Coupon has expired or not yet valid' });
      }

      // Check usage limits
      if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
        return res.status(400).json({ message: 'Coupon usage limit reached' });
      }

      // Check user usage limit
      const userUsageCount = await CouponUsage.countDocuments({
        coupon: coupon._id,
        user: req.user._id
      });

      if (userUsageCount >= coupon.userUsageLimit) {
        return res.status(400).json({ message: 'You have already used this coupon' });
      }

      // Check minimum order value
      if (price < coupon.minOrderValue) {
        return res.status(400).json({
          message: `Minimum order value of ₹${coupon.minOrderValue} required`
        });
      }

      // Calculate discount
      if (coupon.type === 'percentage') {
        couponDiscount = (price * coupon.value) / 100;
        if (coupon.maxDiscount && couponDiscount > coupon.maxDiscount) {
          couponDiscount = coupon.maxDiscount;
        }
      } else {
        couponDiscount = coupon.value;
      }

      couponDiscount = Math.round(couponDiscount);
      totalPrice -= couponDiscount;
      couponId = coupon._id;
      actualCouponCode = coupon.code;

      // Update coupon usage count
      coupon.usageCount += 1;
      await coupon.save();
    }

    // ========== COINS DEDUCTION ==========
    if (coinsUsed && coinsUsed > 0) {
      // Get coin config
      const config = await CoinConfig.findOne();
      const coinToRupeeRate = config?.coinToRupeeRate || 1;
      const maxUsagePercentage = config?.maxUsagePercentage || 50;

      // Calculate max coins that can be used on remaining amount
      const maxAmountFromCoins = (totalPrice * maxUsagePercentage) / 100;
      const maxCoinsAllowed = Math.floor(maxAmountFromCoins / coinToRupeeRate);

      if (coinsUsed > maxCoinsAllowed) {
        return res.status(400).json({
          message: `You can only use up to ${maxCoinsAllowed} coins for this booking (${maxUsagePercentage}% of order)`
        });
      }

      // Deduct coins
      try {
        await deductCoins(req.user._id, null, coinsUsed); // bookingId will be added later
        coinDiscount = coinsUsed * coinToRupeeRate;
        totalPrice -= coinDiscount;
      } catch (error) {
        return res.status(400).json({ message: error.message });
      }
    }

    const finalPrice = Math.max(0, totalPrice);

    // Create booking
    const booking = new Booking({
      user: req.user._id,
      worker: workerId,
      category,
      service,
      description,
      bookingDate,
      bookingTime,
      address,
      price, // Original price
      totalPrice: price, // Total before discounts
      couponApplied: couponId,
      couponCode: actualCouponCode,
      couponDiscount,
      coinsUsed: coinsUsed || 0,
      coinDiscount,
      finalPrice,
      paymentStatus: paymentStatus || 'pending',
      paymentId,
      bookingType: bookingType || 'full-day',
      days: days || 1,
      startDate,
      endDate,
      status: 'pending',
    });

    const createdBooking = await booking.save();

    // Record coupon usage
    if (couponId) {
      await CouponUsage.create({
        coupon: couponId,
        user: req.user._id,
        booking: createdBooking._id,
        discountAmount: couponDiscount
      });
    }

    // Award cashback coins
    if (finalPrice > 0) {
      const cashbackEarned = await awardCashback(req.user._id, createdBooking._id, finalPrice);
      if (cashbackEarned) {
        createdBooking.cashbackEarned = cashbackEarned;
        await createdBooking.save();
      }
    }

    // Notify Worker
    if (req.io) {
      req.io.to(workerId).emit('booking_created', {
        message: 'New booking request received!',
        booking: createdBooking,
      });
    }

    res.status(201).json(createdBooking);
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ message: 'Server error while creating booking.' });
  }
};

// @desc    Create multiple bookings (Bulk)
// @route   POST /api/bookings/bulk
// @access  Private (User)
export const createBulkBookings = async (req, res) => {
  const {
    bookings, // Array of booking objects
    paymentStatus,
    paymentId,
    couponCode,
    coinsUsed,
    address // Shared address for all bookings
  } = req.body;

  if (!bookings || !Array.isArray(bookings) || bookings.length === 0) {
    return res.status(400).json({ message: 'No bookings provided.' });
  }

  try {
    // 1. Calculate Total Price
    let totalOrderPrice = 0;
    for (const item of bookings) {
      if (!item.price) {
        return res.status(400).json({ message: 'Price is required for all items.' });
      }
      totalOrderPrice += item.price;
    }

    let totalCouponDiscount = 0;
    let totalCoinDiscount = 0;
    let couponId = null;
    let actualCouponCode = null;

    // 2. Coupon Validation (Once for the whole order)
    if (couponCode) {
      const coupon = await Coupon.findOne({ code: couponCode.toUpperCase() });

      if (!coupon) {
        return res.status(400).json({ message: 'Invalid coupon code' });
      }

      if (!coupon.isActive) {
        return res.status(400).json({ message: 'Coupon is not active' });
      }

      const now = new Date();
      if (now < coupon.validFrom || now > coupon.validUntil) {
        return res.status(400).json({ message: 'Coupon has expired or not yet valid' });
      }

      if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
        return res.status(400).json({ message: 'Coupon usage limit reached' });
      }

      const userUsageCount = await CouponUsage.countDocuments({
        coupon: coupon._id,
        user: req.user._id
      });

      if (userUsageCount >= coupon.userUsageLimit) {
        return res.status(400).json({ message: 'You have already used this coupon' });
      }

      if (totalOrderPrice < coupon.minOrderValue) {
        return res.status(400).json({
          message: `Minimum order value of ₹${coupon.minOrderValue} required`
        });
      }

      // Calculate discount
      if (coupon.type === 'percentage') {
        totalCouponDiscount = (totalOrderPrice * coupon.value) / 100;
        if (coupon.maxDiscount && totalCouponDiscount > coupon.maxDiscount) {
          totalCouponDiscount = coupon.maxDiscount;
        }
      } else {
        totalCouponDiscount = coupon.value;
      }

      totalCouponDiscount = Math.round(totalCouponDiscount);
      couponId = coupon._id;
      actualCouponCode = coupon.code;

      // Update coupon usage count
      coupon.usageCount += 1;
      await coupon.save();
    }

    // 3. Coins Deduction (Once for the whole order)
    if (coinsUsed && coinsUsed > 0) {
      const config = await CoinConfig.findOne();
      const coinToRupeeRate = config?.coinToRupeeRate || 1;
      const maxUsagePercentage = config?.maxUsagePercentage || 50;

      // Calculate max coins based on total price (after coupon if you want, but usually on base price or price-coupon)
      // Let's follow the logic: Price - Coupon - Coins
      const priceAfterCoupon = totalOrderPrice - totalCouponDiscount;
      const maxAmountFromCoins = (priceAfterCoupon * maxUsagePercentage) / 100;
      const maxCoinsAllowed = Math.floor(maxAmountFromCoins / coinToRupeeRate);

      if (coinsUsed > maxCoinsAllowed) {
        return res.status(400).json({
          message: `You can only use up to ${maxCoinsAllowed} coins for this order`
        });
      }

      try {
        await deductCoins(req.user._id, null, coinsUsed);
        totalCoinDiscount = coinsUsed * coinToRupeeRate;
      } catch (error) {
        return res.status(400).json({ message: error.message });
      }
    }

    // 4. Create Bookings
    const createdBookings = [];
    let remainingCouponDiscount = totalCouponDiscount;
    let remainingCoinDiscount = totalCoinDiscount;
    let remainingCoinsUsed = coinsUsed || 0;

    for (let i = 0; i < bookings.length; i++) {
      const item = bookings[i];
      const isLast = i === bookings.length - 1;

      // Distribute discounts proportionally
      let itemCouponDiscount = 0;
      let itemCoinDiscount = 0;
      let itemCoinsUsed = 0;

      if (totalOrderPrice > 0) {
        if (isLast) {
          itemCouponDiscount = remainingCouponDiscount;
          itemCoinDiscount = remainingCoinDiscount;
          itemCoinsUsed = remainingCoinsUsed;
        } else {
          const ratio = item.price / totalOrderPrice;
          itemCouponDiscount = Math.floor(totalCouponDiscount * ratio);
          itemCoinDiscount = Math.floor(totalCoinDiscount * ratio);
          itemCoinsUsed = Math.floor((coinsUsed || 0) * ratio);

          remainingCouponDiscount -= itemCouponDiscount;
          remainingCoinDiscount -= itemCoinDiscount;
          remainingCoinsUsed -= itemCoinsUsed;
        }
      }

      const finalPrice = Math.max(0, item.price - itemCouponDiscount - itemCoinDiscount);

      const booking = new Booking({
        user: req.user._id,
        worker: item.workerId,
        category: item.category,
        service: item.service,
        description: item.description,
        bookingDate: item.bookingDate,
        bookingTime: item.bookingTime,
        address: address, // Use shared address
        price: item.price,
        totalPrice: item.price,
        couponApplied: couponId,
        couponCode: actualCouponCode,
        couponDiscount: itemCouponDiscount,
        coinsUsed: itemCoinsUsed,
        coinDiscount: itemCoinDiscount,
        finalPrice,
        paymentStatus: paymentStatus || 'pending',
        paymentId,
        bookingType: item.bookingType,
        days: item.days,
        startDate: item.startDate,
        endDate: item.endDate,
        status: 'pending',
      });

      const savedBooking = await booking.save();
      createdBookings.push(savedBooking);

      // Award cashback - TODO: Implement awardCashback function
      // if (finalPrice > 0) {
      //   const cashbackEarned = await awardCashback(req.user._id, savedBooking._id, finalPrice);
      //   if (cashbackEarned) {
      //     savedBooking.cashbackEarned = cashbackEarned;
      //     await savedBooking.save();
      //   }
      // }

      // Notify Worker
      if (req.io) {
        req.io.to(item.workerId).emit('booking_created', {
          message: 'New booking request received!',
          booking: savedBooking,
        });
      }
    }

    // 5. Record Coupon Usage (Link to the first booking for reference)
    if (couponId && createdBookings.length > 0) {
      await CouponUsage.create({
        coupon: couponId,
        user: req.user._id,
        booking: createdBookings[0]._id, // Link to first booking
        discountAmount: totalCouponDiscount
      });
    }

    res.status(201).json(createdBookings);

  } catch (error) {
    console.error('Error creating bulk bookings:', error);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    res.status(500).json({ message: error.message || 'Server error while creating bookings.' });
  }
};

// @desc    Get all bookings for the logged-in user
// @route   GET /api/bookings/my
// @access  Private (User)
export const getUserBookings = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationParams(req.query);

    const [bookings, total] = await Promise.all([
      Booking.find({ user: req.user._id })
        .populate('worker', 'firstName lastName mobileNumber livePhoto price')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Booking.countDocuments({ user: req.user._id })
    ]);

    res.json(createPaginatedResponse(bookings, total, page, limit));
  } catch (error) {
    console.error('Error fetching user bookings:', error);
    res.status(500).json({ message: 'Server error while fetching user bookings.' });
  }
};

// @desc    Get all bookings for the logged-in worker
// @route   GET /api/bookings/worker/my
// @access  Private (Worker)
export const getWorkerBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ worker: req.user._id }) // Assuming worker's user ID is stored in req.user._id
      .populate('user', 'name email phone') // Populate user details
      .sort({ createdAt: -1 }); // Newest first
    res.json(bookings);
  } catch (error) {
    console.error('Error fetching worker bookings:', error);
    res.status(500).json({ message: 'Server error while fetching worker bookings.' });
  }
};

// Helper function to credit YC Coins
const creditYCCoinsToUser = async (userId, bookingId) => {
  try {
    const coinsToCredit = 5; // Fixed 5 coins
    if (coinsToCredit > 0) {
      // Ensure wallet exists and then credit coins
      const wallet = await ensureWallet(userId);
      // Directly update the wallet and add a transaction.
      wallet.ycCoins += coinsToCredit;
      wallet.transactions.push({
        type: 'credit',
        amount: coinsToCredit,
        coinAmount: coinsToCredit,
        note: `Earned ${coinsToCredit} YC Coins for booking ${bookingId}`,
        meta: { bookingId: bookingId.toString() },
      });
      await wallet.save();
      console.log(`Credited ${coinsToCredit} YC Coins to user ${userId} for booking ${bookingId}`);
      return true;
    }
    return false;
  } catch (error) {
    console.error(`Failed to credit YC Coins for user ${userId}, booking ${bookingId}:`, error);
    return false;
  }
};


// @desc    Update booking status (worker/admin)
// @route   PUT /api/bookings/:id/status
// @access  Private (Worker/Admin)
export const updateStatus = async (req, res) => {
  const { status } = req.body;
  const { id } = req.params; // Booking ID

  try {
    const booking = await Booking.findById(id);

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found.' });
    }

    // Authorization: Only the assigned worker or an admin can update status
    if (req.user.role === 'worker' && booking.worker.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this booking status.' });
    }
    // Admin can update any booking status
    // For simplicity, assuming req.user.role is 'admin' for admin users.
    // You might need to implement a proper role-based access control (RBAC) middleware.

    // Validate status transition
    const validTransitions = {
      'pending': ['accepted', 'rejected'],
      'accepted': ['in-progress', 'cancelled'], // Worker can cancel accepted booking
      'in-progress': ['completed'],
      // Admin can override any status
    };

    if (req.user.role !== 'admin' && (!validTransitions[booking.status] || !validTransitions[booking.status].includes(status))) {
      return res.status(400).json({ message: `Invalid status transition from ${booking.status} to ${status}.` });
    }

    booking.status = status;

    // Handle YC Coin reward on completion
    if (status === 'completed' && !booking.isYcCoinsCredited) {
      const credited = await creditYCCoinsToUser(booking.user, booking._id);
      if (credited) {
        booking.ycCoinsEarned = 5;
        booking.isYcCoinsCredited = true;
      }
    }

    const updatedBooking = await booking.save();

    // Notify User
    if (req.io) {
      req.io.to(booking.user.toString()).emit('booking_status_updated', {
        message: `Your booking status is now ${status}`,
        booking: updatedBooking,
      });
    }

    res.json(updatedBooking);
  } catch (error) {
    console.error('Error updating booking status:', error);
    res.status(500).json({ message: 'Server error while updating booking status.' });
  }
};

// @desc    Cancel a booking (User)
// @route   PUT /api/bookings/:id/cancel
// @access  Private (User)
export const cancelBooking = async (req, res) => {
  const { id } = req.params; // Booking ID

  try {
    const booking = await Booking.findById(id);

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found.' });
    }

    // Authorization: Only the user who created the booking can cancel it
    if (booking.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to cancel this booking.' });
    }

    // Only pending bookings can be cancelled by the user
    if (booking.status !== 'pending') {
      return res.status(400).json({ message: `Booking cannot be cancelled as its status is '${booking.status}'.` });
    }

    booking.status = 'cancelled';
    const updatedBooking = await booking.save();
    res.json(updatedBooking);
  } catch (error) {
    console.error('Error cancelling booking:', error);
    res.status(500).json({ message: 'Server error while cancelling booking.' });
  }
};

// @desc    Admin override booking status
// @route   PUT /api/bookings/:id/admin-status
// @access  Private (Admin)
export const adminOverrideStatus = async (req, res) => {
  const { status } = req.body;
  const { id } = req.params; // Booking ID

  try {
    const booking = await Booking.findById(id);

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found.' });
    }

    // Authorization: Only admin can override status
    // This assumes you have a role field in your User model and a middleware to check it.
    // For now, let's assume req.user.isAdmin is true for admin users.
    // You might need to implement a proper role-based access control (RBAC) middleware.
    if (!req.user.isAdmin) { // Assuming isAdmin field in user object
      return res.status(403).json({ message: 'Not authorized to perform this action.' });
    }

    // Validate new status
    const validStatuses = ['pending', 'accepted', 'in-progress', 'completed', 'cancelled', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status provided.' });
    }

    booking.status = status;

    // Handle YC Coin reward on completion if admin sets to completed
    if (status === 'completed' && !booking.isYcCoinsCredited) {
      const credited = await creditYCCoinsToUser(booking.user, booking._id);
      if (credited) {
        booking.ycCoinsEarned = 5;
        booking.isYcCoinsCredited = true;
      }
    }

    const updatedBooking = await booking.save();
    res.json(updatedBooking);
  } catch (error) {
    console.error('Error admin overriding booking status:', error);
    res.status(500).json({ message: 'Server error while admin overriding booking status.' });
  }
};

// @desc    Get a single booking by ID
// @route   GET /api/bookings/:id
// @access  Private (User/Worker/Admin)
export const getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('user', 'name email phone')
      .populate('worker', 'firstName lastName mobileNumber livePhoto price');

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    // Authorization: Only the user who created the booking, the assigned worker, or an admin can view it
    if (
      booking.user._id.toString() !== req.user._id.toString() &&
      booking.worker._id.toString() !== req.user._id.toString() &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ message: 'Not authorized to view this booking' });
    }

    res.json(booking);
  } catch (error) {
    console.error('Error fetching booking by ID:', error);
    res.status(500).json({ message: 'Server error' });
  }
};



// @desc    Accept a booking (Worker)
// @route   PUT /api/bookings/:id/accept
// @access  Private (Worker)
export const acceptBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('user', 'name mobileNumber');

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    // Verify this worker is assigned to this booking
    if (booking.worker.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to accept this booking' });
    }

    // Check if already accepted or rejected
    if (booking.status === 'accepted') {
      return res.status(400).json({ message: 'Booking already accepted' });
    }

    if (booking.status === 'rejected') {
      return res.status(400).json({ message: 'Cannot accept a rejected booking' });
    }

    booking.status = 'accepted';
    const updatedBooking = await booking.save();

    // Notify user via Socket.IO
    if (req.io) {
      req.io.to(booking.user._id.toString()).emit('booking_accepted', {
        message: 'Your booking has been accepted!',
        booking: updatedBooking
      });
    }

    res.json({ message: 'Booking accepted successfully', booking: updatedBooking });
  } catch (error) {
    console.error('Error accepting booking:', error);
    res.status(500).json({ message: 'Server error while accepting booking' });
  }
};

// @desc    Reject a booking (Worker)
// @route   PUT /api/bookings/:id/reject
// @access  Private (Worker)
export const rejectBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('user', 'name mobileNumber');

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    // Verify this worker is assigned to this booking
    if (booking.worker.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to reject this booking' });
    }

    // Check if already accepted or rejected
    if (booking.status === 'accepted') {
      return res.status(400).json({ message: 'Cannot reject an accepted booking' });
    }

    if (booking.status === 'rejected') {
      return res.status(400).json({ message: 'Booking already rejected' });
    }

    booking.status = 'rejected';
    const updatedBooking = await booking.save();

    // Notify user via Socket.IO
    if (req.io) {
      req.io.to(booking.user._id.toString()).emit('booking_rejected', {
        message: 'Your booking has been rejected',
        booking: updatedBooking
      });
    }

    res.json({ message: 'Booking rejected', booking: updatedBooking });
  } catch (error) {
    console.error('Error rejecting booking:', error);
    res.status(500).json({ message: 'Server error while rejecting booking' });
  }
};