import User from "../model/User.js";
import Worker from "../model/Worker.js";
import { createToken } from '../utils/jwt.js';
import { ensureWallet } from "./userwalletController.js";
import { createOTP, verifyOTP as verifyOTPService } from '../utils/otpService.js';

// Send OTP
export const sendOTP = async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return res.status(400).json({ message: "Phone number is required" });
    }

    // Validate phone number format (basic validation)
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phone)) {
      return res.status(400).json({ message: "Invalid phone number format" });
    }

    // Create OTP using service (handles rate limiting)
    const result = await createOTP(phone);

    res.json({
      message: "OTP sent successfully",
      otp: result.otp, // In production, remove this and send via SMS/Email
      expiresIn: result.expiresIn // seconds
    });
  } catch (error) {
    console.error('Send OTP error:', error);

    // Handle rate limit errors
    if (error.message.includes('Too many OTP requests')) {
      return res.status(429).json({ message: error.message });
    }

    res.status(500).json({ message: error.message || "Server Error" });
  }
};

// Verify OTP
export const verifyOTP = async (req, res) => {
  try {
    const { phone, otp } = req.body;

    if (!phone || !otp) {
      return res.status(400).json({ message: "Phone and OTP are required" });
    }

    // Verify OTP using service (handles attempts and expiry)
    try {
      await verifyOTPService(phone, otp);
    } catch (otpError) {
      return res.status(400).json({ message: otpError.message });
    }

    // OTP verified successfully, now check user type

    // 1. Check if it's a Worker
    const worker = await Worker.findOne({ mobileNumber: phone });
    if (worker) {
      // Generate Token for Worker
      const token = createToken(worker._id, 'worker');

      return res.json({
        message: "Worker Login Successful",
        user: { ...worker.toObject(), role: 'worker' },
        token,
        userType: 'worker'
      });
    }

    // 2. Check if it's a User
    let user = await User.findOne({ phone });

    // If user does not exist -> Return isNewUser flag
    if (!user) {
      return res.json({ isNewUser: true, phone });
    }

    // Ensure wallet exists for existing user (idempotent)
    await ensureWallet(user._id);

    // Generate Token for User
    const token = createToken(user._id, 'user');

    res.json({
      message: "Login Successful",
      user: { ...user.toObject(), role: 'user' },
      token,
      userType: 'user'
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ message: "Server Error" });
  }
};

// Register User
export const register = async (req, res) => {
  try {
    const { name, phone, userType } = req.body;

    if (!name || !phone) {
      return res.status(400).json({ message: "Name and Phone are required" });
    }

    // Check if user already exists
    let existingUser = await User.findOne({ phone });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Create new user
    const user = await User.create({
      name,
      email: req.body.email || undefined,
      phone,
      role: userType || 'user'
    });

    // Ensure wallet is created
    await ensureWallet(user._id);

    // Generate Token
    const token = createToken(user._id, user.role);

    res.status(201).json({
      message: "Registration Successful",
      user: { ...user.toObject(), role: user.role },
      token,
      userType: user.role
    });

  } catch (error) {
    console.error("Registration Error:", error);
    res.status(500).json({ message: "Server Error" });
  }
};
