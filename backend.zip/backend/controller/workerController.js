import Worker from '../model/Worker.js';
import Category from '../model/Category.js';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import { getPaginationParams, createPaginatedResponse } from '../utils/paginationHelper.js';
import cacheService, { cacheKeys, cacheTTL } from '../utils/cacheService.js';

// @desc    Get all workers (with optional filters)
// @route   GET /api/workers
// @access  Public (was Admin, now public for user booking page)
export const getWorkers = async (req, res) => {
  try {
    const { category, subcategory, minPrice, maxPrice, minRating, latitude, longitude, maxDistance } = req.query;

    // Get pagination params
    const { page, limit, skip } = getPaginationParams(req.query);

    let matchQuery = {};

    // Default to approved unless status is explicitly specified
    if (req.query.status && req.query.status !== 'all') {
      matchQuery.status = req.query.status;
    } else if (req.query.status === 'all') {
      // No status filter, return all
    } else {
      matchQuery.status = 'approved';
    }

    // Filter by subcategory/service name
    if (subcategory) {
      matchQuery.services = { $regex: new RegExp(subcategory, 'i') };
    }

    // Filter by category
    if (category) {
      matchQuery.categories = { $regex: new RegExp(category, 'i') };
    }

    // Price filter
    if (minPrice || maxPrice) {
      matchQuery.price = {};
      if (minPrice) matchQuery.price.$gte = Number(minPrice);
      if (maxPrice) matchQuery.price.$lte = Number(maxPrice);
    }

    // Rating filter
    if (minRating) {
      matchQuery.averageRating = { $gte: Number(minRating) };
    }

    // If location is provided, use aggregation for distance
    if (latitude && longitude) {
      const lat = parseFloat(latitude);
      const lng = parseFloat(longitude);

      const pipeline = [
        {
          $geoNear: {
            near: { type: 'Point', coordinates: [lng, lat] },
            distanceField: 'distance',
            maxDistance: maxDistance ? Number(maxDistance) * 1000 : 50000,
            query: matchQuery,
            spherical: true,
            distanceMultiplier: 0.001,
          },
        },
        {
          $addFields: {
            distance: { $round: ['$distance', 1] }
          }
        },
        { $skip: skip },
        { $limit: limit }
      ];

      if (req.query.sortBy === 'rating') {
        pipeline.splice(2, 0, { $sort: { averageRating: -1 } });
      }

      const [workers, totalCount] = await Promise.all([
        Worker.aggregate(pipeline),
        Worker.countDocuments(matchQuery)
      ]);

      return res.json(createPaginatedResponse(workers, totalCount, page, limit));
    }

    // Fallback to normal find with pagination
    const [workers, total] = await Promise.all([
      Worker.find(matchQuery)
        .sort({ averageRating: -1, createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Worker.countDocuments(matchQuery)
    ]);

    res.json(createPaginatedResponse(workers, total, page, limit));
  } catch (error) {
    console.error("Error fetching workers:", error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Register a new worker
// @route   POST /api/workers/register
// @access  Public
export const registerWorker = async (req, res) => {
  const {
    firstName,
    lastName,
    mobileNumber,
    state,
    district,
    city,
    latitude, // Added latitude
    longitude, // Added longitude
    aadhaarNumber, // New
    panNumber, // New
    categories,
    services,
    price, // Keep for backward compatibility
  } = req.body;

  let { servicePricing } = req.body;

  // Parse servicePricing if it's a string (from FormData)
  if (typeof servicePricing === 'string') {
    try {
      servicePricing = JSON.parse(servicePricing);
    } catch (error) {
      console.error('Error parsing servicePricing:', error);
      return res.status(400).json({ message: 'Invalid service pricing format' });
    }
  }

  if (!req.files || !req.files.livePhoto || !req.files.aadhaarCard) { // Changed idProof to aadhaarCard
    return res.status(400).json({ message: 'Please upload live photo and Aadhaar card.' });
  }

  const livePhoto = req.files.livePhoto[0].filename;
  const aadhaarCard = req.files.aadhaarCard[0].filename; // New
  const panCard = req.files.panCard ? req.files.panCard[0].filename : null; // Optional

  try {
    const workerExists = await Worker.findOne({ mobileNumber });

    if (workerExists) {
      return res.status(400).json({ message: 'Worker already exists with this mobile number' });
    }

    // Validate servicePricing if provided
    let validatedServicePricing = [];
    if (servicePricing && Array.isArray(servicePricing) && servicePricing.length > 0) {
      // Validate each service
      for (const service of servicePricing) {
        if (!service.serviceName || !service.price || service.price < 0) {
          return res.status(400).json({
            message: 'Each service must have a name and valid price'
          });
        }

        validatedServicePricing.push({
          subCategory: service.subCategoryId || null,
          categoryName: service.categoryName || '',
          serviceName: service.serviceName,
          price: parseFloat(service.price),
          isActive: true
        });
      }
    }

    // Validate and parse coordinates
    const parsedLat = latitude ? parseFloat(latitude) : null;
    const parsedLng = longitude ? parseFloat(longitude) : null;

    // Build worker data object
    const workerData = {
      firstName,
      lastName,
      mobileNumber,
      state,
      district,
      city,
      latitude: parsedLat,
      longitude: parsedLng,
      livePhoto,
      aadhaarNumber,
      aadhaarCard,
      panNumber,
      panCard,
      categories,
      services,
      servicePricing: validatedServicePricing.length > 0 ? validatedServicePricing : [],
      price: price || 0, // Fallback to old system
    };

    // Only add location if both coordinates are valid numbers
    if (parsedLat && parsedLng && !isNaN(parsedLat) && !isNaN(parsedLng)) {
      workerData.location = {
        type: 'Point',
        coordinates: [parsedLng, parsedLat],
      };
    }

    const worker = new Worker(workerData);

    const createdWorker = await worker.save();

    // Generate Token
    const token = jwt.sign({ id: createdWorker._id, role: 'worker' }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      worker: { ...createdWorker.toObject(), role: 'worker' },
      token
    });
  } catch (error) {
    console.error('Worker registration error:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// @desc    Get workers by sub-category
// @route   GET /api/workers/subcategory/:subCategoryId
// @access  Public
export const getWorkersBySubCategory = async (req, res) => {
  try {
    const { subCategoryId } = req.params;

    if (!subCategoryId || !mongoose.Types.ObjectId.isValid(subCategoryId)) {
      console.error(`Invalid or missing subCategoryId: ${subCategoryId}`);
      return res.status(400).json({ message: 'Invalid or missing sub-category ID' });
    }
    const { minPrice, maxPrice, minRating, latitude, longitude, maxDistance } = req.query;

    const category = await Category.findOne({ 'subCategories._id': subCategoryId });

    if (!category) {
      console.log(`Sub-category not found for ID: ${subCategoryId}`);
      return res.status(404).json({ message: 'Sub-category not found' });
    }
    console.log(`Found category: ${category.name} for subCategoryId: ${subCategoryId}`);

    const subCategory = category.subCategories.id(subCategoryId);

    // Base query: Workers offering this service
    let matchQuery = { services: { $in: [subCategory.name] } };

    // Price Filter
    if (minPrice || maxPrice) {
      matchQuery.price = {};
      if (minPrice) matchQuery.price.$gte = Number(minPrice);
      if (maxPrice) matchQuery.price.$lte = Number(maxPrice);
    }

    // Rating Filter
    if (minRating) {
      matchQuery.averageRating = { $gte: Number(minRating) };
    }

    // If location is provided, use aggregation
    if (latitude && longitude) {
      const lat = parseFloat(latitude);
      const lng = parseFloat(longitude);

      const pipeline = [
        {
          $geoNear: {
            near: { type: 'Point', coordinates: [lng, lat] },
            distanceField: 'distance',
            maxDistance: maxDistance ? Number(maxDistance) * 1000 : 50000, // Default 50km
            query: matchQuery,
            spherical: true,
            distanceMultiplier: 0.001, // Convert meters to km
          },
        },
        {
          $addFields: {
            distance: { $round: ['$distance', 1] }
          }
        }
      ];

      // Apply sorting if requested
      // Apply sorting if requested
      if (req.query.sortBy === 'rating') {
        pipeline.push({ $sort: { averageRating: -1 } });
      } else {
        // Default sort by distance (already done by $geoNear, but explicit is fine)
        // pipeline.push({ $sort: { distance: 1 } });
      }

      try {
        const workers = await Worker.aggregate(pipeline);
        return res.json(workers);
      } catch (aggError) {
        console.error('Aggregation Error in getWorkersBySubCategory:', aggError);
        console.error('Pipeline:', JSON.stringify(pipeline, null, 2));
        return res.status(500).json({ message: 'Aggregation Error', error: aggError.message });
      }
    }

    const workers = await Worker.find(matchQuery);
    res.json(workers);
  } catch (error) {
    console.error('Error getting workers by sub-category:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Approve a worker
// @route   PUT /api/workers/:id/approve
// @access  Admin
export const approveWorker = async (req, res) => {
  try {
    const worker = await Worker.findById(req.params.id);

    if (worker) {
      worker.status = 'approved';
      const updatedWorker = await worker.save();
      res.json(updatedWorker);
    } else {
      res.status(404).json({ message: 'Worker not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Reject a worker
// @route   PUT /api/workers/:id/reject
// @access  Admin
export const rejectWorker = async (req, res) => {
  try {
    const worker = await Worker.findById(req.params.id);

    if (worker) {
      worker.status = 'rejected';
      const updatedWorker = await worker.save();
      res.json(updatedWorker);
    } else {
      res.status(404).json({ message: 'Worker not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get worker by mobile number
// @route   GET /api/workers/mobile/:mobileNumber
// @access  Public
export const getWorkerByMobileNumber = async (req, res) => {
  try {
    const worker = await Worker.findOne({ mobileNumber: req.params.mobileNumber });

    if (worker) {
      res.json(worker);
    } else {
      res.status(404).json({ message: 'Worker not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get worker statistics
// @route   GET /api/workers/:id/stats
// @access  Private (Admin/Worker itself) - for now, just return dummy data
export const getWorkerStats = async (req, res) => {
  try {
    // In a real application, you would fetch actual data from the database
    // e.g., count bookings, calculate earnings, etc.
    const stats = {
      totalBookings: 38,
      pendingBookings: 6,
      activeBookings: 4,
      completedBookings: 28,
      walletBalance: 1000.50,
    };
    res.json(stats);
  } catch (error) {
    console.error('Error fetching worker stats:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get worker notifications
// @route   GET /api/workers/:id/notifications
// @access  Private (Admin/Worker itself) - for now, just return dummy data
export const getWorkerNotifications = async (req, res) => {
  try {
    const notifications = [
      { id: 1, title: 'New job request received', time: '2 mins ago', icon: 'fa-circle-exclamation', color: 'text-yellow-400' },
      { id: 2, title: 'Payment received ₹500', time: '1 hour ago', icon: 'fa-check-circle', color: 'text-green-500' },
      { id: 3, title: 'New 5-star rating!', time: '3 hours ago', icon: 'fa-star', color: 'text-blue-500' },
      { id: 4, title: 'New message from customer', time: '5 hours ago', icon: 'fa-envelope', color: 'text-indigo-500' },
    ];
    res.json(notifications);
  } catch (error) {
    console.error('Error fetching worker notifications:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get worker feedback
// @route   GET /api/workers/:id/feedback
// @access  Private (Admin/Worker itself) - for now, just return dummy data
export const getWorkerFeedback = async (req, res) => {
  try {
    const feedback = [
      { id: 1, name: 'Rahul Sharma', rating: 4, text: 'Quick service and very helpful, recommended!' },
      { id: 2, name: 'Neha Mehta', rating: 3, text: 'Could be faster, but work was neat and professional.' },
      { id: 3, name: 'Amit Verma', rating: 5, text: 'Excellent, very prompt and friendly worker.' },
    ];
    res.json(feedback);
  } catch (error) {
    console.error('Error fetching worker feedback:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Update worker details
// @route   PUT /api/workers/:id
// @access  Admin
export const updateWorkerDetails = async (req, res) => {
  const {
    firstName,
    lastName,
    mobileNumber,
    state,
    district,
    city,
    latitude,
    longitude,
    aadhaarNumber, // New
    panNumber, // New
    categories,
    services,
    status,
    workerType,
    price, // New: Add price field
  } = req.body;

  try {
    const worker = await Worker.findById(req.params.id);

    if (worker) {
      worker.firstName = firstName || worker.firstName;
      worker.lastName = lastName || worker.lastName;
      worker.mobileNumber = mobileNumber || worker.mobileNumber;
      worker.state = state || worker.state;
      worker.district = district || worker.district;
      worker.city = city || worker.city;
      worker.latitude = latitude || worker.latitude;
      worker.longitude = longitude || worker.longitude;
      worker.aadhaarNumber = aadhaarNumber || worker.aadhaarNumber; // New
      worker.panNumber = panNumber || worker.panNumber; // New
      worker.categories = categories || worker.categories;
      worker.services = services || worker.services;
      worker.status = status || worker.status;
      worker.workerType = workerType || worker.workerType;
      worker.price = price || worker.price; // New: Update price

      if (latitude && longitude) {
        worker.location = {
          type: 'Point',
          coordinates: [parseFloat(longitude), parseFloat(latitude)],
        };
      }

      // Handle file uploads if new files are provided
      if (req.files && req.files.livePhoto) {
        worker.livePhoto = req.files.livePhoto[0].filename;
      }
      if (req.files && req.files.aadhaarCard) { // New
        worker.aadhaarCard = req.files.aadhaarCard[0].filename;
      }
      if (req.files && req.files.panCard) { // New
        worker.panCard = req.files.panCard[0].filename;
      }

      const updatedWorker = await worker.save();
      res.json(updatedWorker);
    } else {
      res.status(404).json({ message: 'Worker not found' });
    }
  } catch (error) {
    console.error('Error updating worker details:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get worker by ID
// @route   GET /api/workers/:id
// @access  Public
export const getWorkerById = async (req, res) => {
  try {
    const worker = await Worker.findById(req.params.id);
    if (worker) {
      res.json(worker);
    } else {
      res.status(404).json({ message: 'Worker not found' });
    }
  } catch (error) {
    console.error('Error fetching worker by ID:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};
