import Admin from '../model/Admin.js';

import User from '../model/User.js';
import Worker from '../model/Worker.js';
import Booking from '../model/Booking.js';
import jwt from 'jsonwebtoken';

export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find({});
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

export const getDashboardStats = async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    const workerCount = await Worker.countDocuments(); // Total workers
    const pendingWorkers = await Worker.countDocuments({ status: 'pending' });
    const verifiedWorkers = await Worker.countDocuments({ status: 'approved' });
    const bookingCount = await Booking.countDocuments();

    // Calculate earnings (assuming you have a way to track this, for now using placeholder or aggregation)
    // This is a simplified example. You might need to aggregate from Bookings or UserWallet.
    const earnings = 0; // Replace with actual logic

    res.json({
      users: userCount,
      workers: workerCount,
      workersPending: pendingWorkers,
      verifiedWorkers: verifiedWorkers,
      bookings: bookingCount,
      earnings
    });
  } catch (error) {
    console.error("Stats Error:", error);
    res.status(500).json({ message: 'Server Error' });
  }
};

export const adminRegister = async (req, res) => {
  const { mobileNumber, password } = req.body;

  try {
    // Check if admin with mobile number already exists
    let admin = await Admin.findOne({ mobileNumber });
    if (admin) {
      return res.status(400).json({ message: 'Admin with this mobile number already exists' });
    }

    // Create new admin
    admin = new Admin({
      mobileNumber,
      password, // NOTE: In a real application, hash the password before saving
    });

    await admin.save();

    // Generate Token
    const token = jwt.sign({ id: admin._id, role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      message: 'Admin registered successfully',
      adminId: admin._id,
      token,
      user: {
        _id: admin._id,
        mobileNumber: admin.mobileNumber,
        role: 'admin'
      }
    });

  } catch (error) {
    console.error('Admin registration error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const createUser = async (req, res) => {
  const { name, email, phone } = req.body;

  try {
    const user = new User({
      name,
      email,
      phone,
    });

    const createdUser = await user.save();
    res.status(201).json(createdUser);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

export const deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);

    if (user) {
      res.json({ message: 'User removed' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

export const adminLogin = async (req, res) => {
  let { mobileNumber, password } = req.body;
  if (typeof mobileNumber === 'string') mobileNumber = mobileNumber.trim();
  if (typeof password === 'string') password = password.trim();

  try {
    // Find admin by mobile number
    const admin = await Admin.findOne({ mobileNumber });

    // Check if admin exists
    if (!admin) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Compare passwords (NOTE: In a real application, use bcrypt for password hashing and comparison)
    if (admin.password !== password) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate Token
    const token = jwt.sign({ id: admin._id, role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '7d' });

    // If credentials are valid
    res.status(200).json({
      message: 'Admin login successful',
      adminId: admin._id,
      token,
      user: {
        _id: admin._id,
        mobileNumber: admin.mobileNumber,
        role: 'admin'
      }
    });

  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
