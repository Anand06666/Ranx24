import Worker from '../model/Worker.js';

/**
 * Set worker availability status
 */
export const setAvailability = async (req, res) => {
    try {
        const { isAvailable } = req.body;
        const workerId = req.user._id; // Assuming authenticated worker

        const worker = await Worker.findById(workerId);

        if (!worker) {
            return res.status(404).json({ message: 'Worker not found' });
        }

        worker.isAvailable = isAvailable;
        await worker.save();

        res.json({
            message: `Availability set to ${isAvailable ? 'available' : 'unavailable'}`,
            isAvailable: worker.isAvailable
        });
    } catch (error) {
        console.error('Error setting availability:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

/**
 * Get worker availability status
 */
export const getAvailability = async (req, res) => {
    try {
        const { workerId } = req.params;

        const worker = await Worker.findById(workerId).select('isAvailable workingHours');

        if (!worker) {
            return res.status(404).json({ message: 'Worker not found' });
        }

        res.json({
            isAvailable: worker.isAvailable || false,
            workingHours: worker.workingHours || {}
        });
    } catch (error) {
        console.error('Error getting availability:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

/**
 * Update working hours
 */
export const updateWorkingHours = async (req, res) => {
    try {
        const { workingHours } = req.body;
        const workerId = req.user._id;

        const worker = await Worker.findById(workerId);

        if (!worker) {
            return res.status(404).json({ message: 'Worker not found' });
        }

        worker.workingHours = workingHours;
        await worker.save();

        res.json({
            message: 'Working hours updated successfully',
            workingHours: worker.workingHours
        });
    } catch (error) {
        console.error('Error updating working hours:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

export default {
    setAvailability,
    getAvailability,
    updateWorkingHours
};
