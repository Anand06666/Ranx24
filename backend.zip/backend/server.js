// server.js
import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import AppError from "./utils/AppError.js"; // Import AppError
import globalErrorHandler from "./middleware/errorMiddleware.js"; // Import globalErrorHandler

// ES Module path fix
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load env variables
dotenv.config({ path: path.resolve(__dirname, '.env') });

const app = express();

// Security Middleware
import helmet from 'helmet';

// CORS Middleware - Must be first
app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : ["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173", "http://127.0.0.1:3000"],
  credentials: true
}));

// Helmet for secure HTTP headers
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }, // Allow images to load
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"], // Adjust as needed for scripts
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:", "http://localhost:5000", "https://*.cloudinary.com"], // Add your image sources
      connectSrc: ["'self'", "ws:", "wss:", "http://localhost:5000", "http://127.0.0.1:5000"], // Allow WebSocket and API
    },
  },
}));

// Rate limiting to prevent DDoS attacks
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again after 15 minutes',
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
});

// Apply the rate limiting middleware to all requests
app.use(limiter);

// Middleware

app.use(express.json());

// Input Sanitization Middleware
import { sanitizeMongo, sanitizeXSS, customSanitize } from './middleware/sanitize.js';
app.use(sanitizeMongo); // Prevent NoSQL injection
app.use(sanitizeXSS);   // Prevent XSS attacks
app.use(customSanitize); // Custom sanitization

app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Import Routes
import adminWorkerRoutes from './router/adminWorkerRoutes.js';

import adminRoutes from './router/adminRoutes.js'; // Import admin routes
// Use admin worker routes
app.use('/api/admin/workers', adminWorkerRoutes);
import categoryRoutes from "./router/categoryRoutes.js";
import workerRoutes from "./router/workerRoutes.js";
import userRoutes from "./router/userRoutes.js";
import bookingRoutes from "./router/bookingRoutes.js";
import cityRoutes from "./router/cityRoutes.js";
import cartRoutes from "./router/cartRoutes.js";
import authRoutes from "./router/authRoutes.js";
import userwalletRoutes from "./router/userwalletRoutes.js"; // Import userwalletRoutes
import paymentRoutes from "./router/paymentRoutes.js"; // Import paymentRoutes
import supportRoutes from "./router/supportRoutes.js"; // Import supportRoutes
import reviewRoutes from "./router/reviewRoutes.js"; // Import reviewRoutes
import chatRoutes from "./router/chatRoutes.js"; // Import chatRoutes
import bannerRoutes from "./router/bannerRoutes.js"; // Import bannerRoutes
import couponRoutes from "./router/couponRoutes.js"; // Import couponRoutes
import coinsRoutes from "./router/coinsRoutes.js"; // Import coinsRoutes
import addressRoutes from "./router/addressRoutes.js"; // Import addressRoutes
import availabilityRoutes from "./router/availabilityRoutes.js"; // Import availabilityRoutes

// Use Routes
app.use("/api/admin", adminRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/workers", workerRoutes);
app.use("/api/users", userRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/cities", cityRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/wallet", userwalletRoutes); // Use userwalletRoutes
app.use("/api/payment", paymentRoutes); // Use paymentRoutes
app.use("/api/support", supportRoutes); // Use supportRoutes
app.use("/api/reviews", reviewRoutes); // Use reviewRoutes
app.use("/api/chat", chatRoutes); // Use chatRoutes
app.use("/api/banners", bannerRoutes); // Use bannerRoutes
app.use("/api/coupons", couponRoutes); // Use couponRoutes
app.use("/api/coins", coinsRoutes); // Use coinsRoutes
app.use("/api/addresses", addressRoutes); // Use addressRoutes
app.use("/api/availability", availabilityRoutes); // Use availabilityRoutes

// Test route
app.get("/", (req, res) => {
  res.send("Backend API is running successfully 🚀");
});

// Handle Unhandled Routes
app.all(/(.*)/, (req, res, next) => {
  next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
});

// Global Error Handler
app.use(globalErrorHandler);

// MongoDB Connection
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/yellowcaps";
mongoose
  .connect(MONGO_URI)
  .then(() => console.log("🟢 MongoDB connected successfully"))
  .catch((err) => console.log("🔴 MongoDB connection error:", err));

// Server Start
const PORT = process.env.PORT || 5000;

import { Server } from "socket.io";
import http from "http";

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: ["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173", "http://127.0.0.1:3000"], // Added 127.0.0.1
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true,
  },
});

// Make io accessible to our router
app.use((req, res, next) => {
  req.io = io;
  next();
});

io.on("connection", (socket) => {
  console.log("New client connected:", socket.id);

  // Join a room based on user ID (for targeted notifications)
  socket.on("join_room", (userId) => {
    if (userId) {
      socket.join(userId);
      console.log(`User ${userId} joined room ${userId}`);
    }
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected:", socket.id);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🔥 Server running on port ${PORT}`);
});
