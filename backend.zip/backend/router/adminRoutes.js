import express from 'express';
import { adminLogin, adminRegister, getAllUsers, deleteUser, createUser, getDashboardStats } from '../controller/adminController.js';

const router = express.Router();

// Admin Registration Route
router.post('/register', adminRegister);

// Admin Login Route
router.post('/login', adminLogin);

import { protect, admin } from '../middleware/authMiddleware.js';

// Get dashboard stats
router.get('/stats', protect, admin, getDashboardStats);

// Get all users route
router.get('/users', protect, admin, getAllUsers);

// Create user route
router.post('/users', protect, admin, createUser);

// Delete user route
router.delete('/users/:id', protect, admin, deleteUser);

export default router;
