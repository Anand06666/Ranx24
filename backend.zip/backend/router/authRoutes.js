import express from 'express';
import { sendOTP, verifyOTP, register } from '../controller/authController.js';
import validate from '../middleware/validateMiddleware.js';
import { sendOtpSchema, loginSchema, registerSchema } from '../utils/validationSchemas.js';

const router = express.Router();

// Send OTP (simulated)
router.post('/send-otp', validate(sendOtpSchema), sendOTP);

// Verify OTP
router.post('/verify-otp', validate(loginSchema), verifyOTP);

// Register User
router.post('/register', validate(registerSchema), register);

export default router;