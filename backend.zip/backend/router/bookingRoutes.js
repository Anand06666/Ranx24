import express from 'express';
import {
  createBooking,
  createBulkBookings,
  getUserBookings,
  getWorkerBookings,
  updateStatus,
  cancelBooking,
  adminOverrideStatus,
  getBookingById,
  acceptBooking,
  rejectBooking,
} from '../controller/bookingController.js';
import { protect } from '../middleware/authMiddleware.js';
import validate from '../middleware/validateMiddleware.js';
import { bookingSchema } from '../utils/validationSchemas.js';

const router = express.Router();

// All routes protected
router.use(protect);

// Create a booking (Validation added)
router.post('/', validate(bookingSchema), createBooking); // Create a new booking
router.post('/bulk', createBulkBookings); // Create multiple bookings
router.get('/my', getUserBookings); // Get bookings for the logged-in user
router.put('/:id/cancel', cancelBooking); // Cancel a booking (user)
router.get('/:id', getBookingById); // Get a single booking by ID

// Worker routes (assuming worker role check is done in controller or a separate middleware)
router.get('/worker/my', getWorkerBookings); // Get bookings for the logged-in worker
router.put('/:id/status', updateStatus); // Update booking status (worker/admin)
router.put('/:id/accept', acceptBooking); // Accept booking (worker)
router.put('/:id/reject', rejectBooking); // Reject booking (worker)

// Admin routes (assuming admin role check is done in controller or a separate middleware)
router.put('/:id/admin-status', adminOverrideStatus); // Admin override booking status

export default router;