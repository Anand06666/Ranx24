import express from 'express';
import {
  registerWorker,
  getWorkers,
  getWorkersBySubCategory,
  approveWorker,
  rejectWorker,
  getWorkerByMobileNumber,
  getWorkerStats, // Added
  getWorkerNotifications, // Added
  getWorkerFeedback, // Added
  updateWorkerDetails, // Added
  getWorkerById, // Added
} from '../controller/workerController.js';
import upload from '../middleware/fileUpload.js';

const router = express.Router();

router.route('/').get(getWorkers);
router.route('/nearby').get(getWorkers);
router.route('/register').post(upload, registerWorker);
router.route('/subcategory/:subCategoryId').get(getWorkersBySubCategory);
import { protect, admin } from '../middleware/authMiddleware.js';

router.route('/:id').get(getWorkerById).put(protect, admin, updateWorkerDetails); // Protected update
router.route('/:id/approve').put(protect, admin, approveWorker);
router.route('/:id/reject').put(protect, admin, rejectWorker);
router.route('/mobile/:mobileNumber').get(getWorkerByMobileNumber);
router.route('/:id/stats').get(getWorkerStats);
router.route('/:id/notifications').get(getWorkerNotifications);
router.route('/:id/feedback').get(getWorkerFeedback); // Added missing route

export default router;
