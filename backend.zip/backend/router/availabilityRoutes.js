import express from 'express';
import { setAvailability, getAvailability, updateWorkingHours } from '../controller/availabilityController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// Worker routes (protected)
router.put('/set', protect, setAvailability);
router.put('/working-hours', protect, updateWorkingHours);

// Public routes
router.get('/:workerId', getAvailability);

export default router;
