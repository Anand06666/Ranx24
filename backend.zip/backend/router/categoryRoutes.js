import express from 'express';
import {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getCategoryById, // Added getCategoryById
  createSubCategory,
  updateSubCategory,
  deleteSubCategory,
} from '../controller/categoryController.js';
import uploadMiddleware from '../middleware/fileUpload.js'; // Import the upload middleware

const router = express.Router();

// Routes for categories
router.route('/').get(getCategories).post(uploadMiddleware, createCategory); // Apply uploadMiddleware here
router.route('/:id').get(getCategoryById).put(uploadMiddleware, updateCategory).delete(deleteCategory);

// Routes for sub-categories
router.route('/:id/subcategories').post(uploadMiddleware, createSubCategory);
router.route('/:id/subcategories/:subId').put(uploadMiddleware, updateSubCategory).delete(deleteSubCategory);

export default router;

