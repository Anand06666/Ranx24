import express from 'express';
import {
    getOrCreateChat,
    sendMessage,
    getChatMessages,
    markAsRead,
} from '../controller/chatController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes require authentication
router.use(protect);

router.post('/booking/:bookingId', getOrCreateChat);
router.post('/:chatId/message', sendMessage);
router.get('/:chatId', getChatMessages);
router.patch('/:chatId/read', markAsRead);

export default router;
