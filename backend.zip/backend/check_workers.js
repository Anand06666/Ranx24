import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Worker from './model/Worker.js';

dotenv.config();

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log('MongoDB Connected');
    } catch (error) {
        console.error('Error connecting to MongoDB:', error.message);
        process.exit(1);
    }
};

const checkWorkers = async () => {
    await connectDB();
    try {
        const workers = await Worker.find({ services: 'wood' });
        console.log(`Found ${workers.length} workers offering 'wood'.`);
        process.exit();
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
};

checkWorkers();
