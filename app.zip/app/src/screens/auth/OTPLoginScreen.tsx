import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image, // Added Image import
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useNavigation, NavigationProp } from '@react-navigation/native';
import { COLORS, SPACING, SHADOWS } from '../../constants/theme'; // Added theme imports

// Navigation param types (reuse the same type we use in AppNavigator)
type RootStackParamList = {
  Main: undefined;
  Register: { phone: string };
  // other screens can be added here if needed
};

const OTPLoginScreen: React.FC = () => {
  const [phone, setPhone] = useState<string>('');
  const [otp, setOtp] = useState<string>('');
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const { login } = useAuth();

  // Navigation with proper typing
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();

  // -----------------------------------------------------------------
  // Existing OTP flow
  // -----------------------------------------------------------------
  const handleSendOTP = async (): Promise<void> => {
    if (phone.length !== 10) {
      Toast.show({
        type: 'error',
        text1: 'Invalid Phone',
        text2: 'Please enter a valid 10-digit phone number',
      });
      return;
    }

    try {
      setLoading(true);
      const response = await api.post('/auth/send-otp', { phone });
      setOtpSent(true);
      Toast.show({
        type: 'success',
        text1: 'OTP Sent',
        text2: response.data.otp ? `Your OTP is ${response.data.otp}` : 'Please check your phone for OTP',
      });
    } catch (error: any) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: error.response?.data?.message || 'Failed to send OTP',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (): Promise<void> => {
    if (otp.length !== 4) {
      Toast.show({
        type: 'error',
        text1: 'Invalid OTP',
        text2: 'Please enter a valid 4-digit OTP',
      });
      return;
    }

    try {
      setLoading(true);
      const response = await api.post('/auth/verify-otp', { phone, otp });

      if (response.data.isNewUser) {
        Toast.show({
          type: 'info',
          text1: 'New User',
          text2: 'Please complete your registration',
        });
        navigation.navigate('Register', { phone });
        return;
      }

      // --- Start of change: Added try-catch for login ---
      try {
        const { token, user } = response.data;
        await login(user, token);
        Toast.show({
          type: 'success',
          text1: 'Welcome!',
          text2: `Logged in as ${user.name || user.phone}`,
        });
      } catch (loginError) {
        Toast.show({
          type: 'error',
          text1: 'Login Failed',
          text2: 'Could not save your session. Please try again.',
        });
        console.error('Login failed after OTP verification:', loginError);
      }
      // --- End of change ---

    } catch (error: any) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: error.response?.data?.message || 'Invalid OTP',
      });
    } finally {
      setLoading(false);
    }
  };

  // -----------------------------------------------------------------
  // NEW: Skip Login button – logs in a dummy guest user
  // -----------------------------------------------------------------
  const handleSkipLogin = async (): Promise<void> => {
    const guestUser = {
      name: 'Guest',
      phone: '0000000000',
      role: 'user',
    } as any; // cast to any because we don’t have the full User type here
    const dummyToken = 'skip-token';

    await login(guestUser, dummyToken);
    // Navigate to the main user tab navigator
    navigation.navigate('Main');
  };

  // -----------------------------------------------------------------
  // UI
  // -----------------------------------------------------------------
  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView contentContainerStyle={styles.scrollView}>
          <View style={styles.header}>
            <Image
              source={require('../../../assets/logo.jpg')}
              style={styles.logoImage}
              resizeMode="contain"
            />
            {/* <Text style={styles.logo}>YellowCaps</Text> */}
            <Text style={styles.subtitle}>Your Home Service Partner</Text>
          </View>

          <View style={styles.form}>
            <Text style={styles.title}>
              {otpSent ? 'Enter OTP' : 'Login with Phone'}
            </Text>

            {!otpSent ? (
              <>
                <TextInput
                  style={styles.input}
                  placeholder="Enter 10-digit phone number"
                  placeholderTextColor={COLORS.textLight}
                  keyboardType="phone-pad"
                  maxLength={10}
                  value={phone}
                  onChangeText={setPhone}
                />
                <TouchableOpacity
                  style={[styles.button, loading && styles.buttonDisabled]}
                  onPress={handleSendOTP}
                  disabled={loading}
                >
                  <Text style={styles.buttonText}>
                    {loading ? 'Sending...' : 'Send OTP'}
                  </Text>
                </TouchableOpacity>

                {/* ---- NEW Skip Login button ---- */}
                <TouchableOpacity
                  style={[styles.linkButton, loading && styles.buttonDisabled]}
                  onPress={handleSkipLogin}
                  disabled={loading}
                >
                  <Text style={styles.linkText}>Skip Login (Guest)</Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                <Text style={styles.phoneText}>Phone: +91 {phone}</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter 4-digit OTP"
                  placeholderTextColor={COLORS.textLight}
                  keyboardType="number-pad"
                  maxLength={4}
                  value={otp}
                  onChangeText={setOtp}
                />
                <TouchableOpacity
                  style={[styles.button, loading && styles.buttonDisabled]}
                  onPress={handleVerifyOTP}
                  disabled={loading}
                >
                  <Text style={styles.buttonText}>
                    {loading ? 'Verifying...' : 'Verify OTP'}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.linkButton}
                  onPress={() => {
                    setOtpSent(false);
                    setOtp('');
                  }}
                >
                  <Text style={styles.linkText}>Change Phone Number</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  keyboardView: { flex: 1 },
  scrollView: { flexGrow: 1, justifyContent: 'center', padding: SPACING.l },
  header: { alignItems: 'center', marginBottom: SPACING.xl },
  logoImage: { width: 150, height: 150, marginBottom: SPACING.s },
  logo: { fontSize: 36, fontWeight: 'bold', color: COLORS.secondary, marginBottom: SPACING.s },
  subtitle: { fontSize: 16, color: COLORS.textLight, fontWeight: '500' },
  form: {
    backgroundColor: COLORS.white,
    borderRadius: 24,
    padding: SPACING.l,
    ...SHADOWS.medium,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.l,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1.5,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: SPACING.m,
    fontSize: 16,
    color: COLORS.text,
    backgroundColor: COLORS.inputBackground,
    marginBottom: SPACING.m,
  },
  button: {
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    padding: SPACING.m,
    alignItems: 'center',
    marginTop: SPACING.s,
    ...SHADOWS.small,
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: COLORS.secondary, fontSize: 16, fontWeight: 'bold' },
  phoneText: {
    fontSize: 16,
    color: COLORS.textLight,
    marginBottom: SPACING.m,
    textAlign: 'center',
  },
  linkButton: { marginTop: SPACING.m, alignItems: 'center' },
  linkText: { color: COLORS.secondary, fontSize: 14, fontWeight: '600' },
});

export default OTPLoginScreen;