import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Image,
    FlatList,
    RefreshControl,
    TextInput,
    ActivityIndicator
} from 'react-native';
import * as Location from 'expo-location';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import api, { API_URL } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { COLORS, SPACING, SHADOWS } from '../../constants/theme';

const HomeScreen = ({ navigation }) => {
    const [categories, setCategories] = useState([]);
    const [workers, setWorkers] = useState([]);
    const [banners, setBanners] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [locationText, setLocationText] = useState("Fetching location...");
    const { user } = useAuth();

    useEffect(() => {
        loadLocation();
        fetchData();
    }, []);

    const loadLocation = async () => {
        try {
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== "granted") {
                setLocationText("Permission Denied");
                return;
            }

            let location = await Location.getCurrentPositionAsync({});

            try {
                let geo = await Location.reverseGeocodeAsync({
                    latitude: location.coords.latitude,
                    longitude: location.coords.longitude
                });

                if (geo && geo.length > 0) {
                    setLocationText(
                        `${geo[0].name || ""}, ${geo[0].district || geo[0].city || ""}`
                    );
                } else {
                    setLocationText("Location Found");
                }
            } catch (geoError) {
                console.log("Geocoding error:", geoError);
                setLocationText("Current Location");
            }
        } catch (err) {
            console.log("Location error:", err);
            setLocationText("Select Location");
        }
    };

    const fetchData = async () => {
        try {
            setError(null);
            const categoriesRes = await api.get('/categories');
            setCategories(categoriesRes.data);

            try {
                const bannersRes = await api.get('/banners/active/home');
                setBanners(bannersRes.data);
            } catch (bannerErr) {
                console.log('Banner fetch error:', bannerErr);
            }

            try {
                const workersRes = await api.get('/workers?limit=5');
                setWorkers(workersRes.data);
            } catch (workerErr) {
                console.log('Workers fetch error:', workerErr);
                setWorkers([]);
            }
        } catch (err: any) {
            console.error('Data fetch error:', err);
            setError(err.message || 'Failed to load data');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const onRefresh = () => {
        setRefreshing(true);
        loadLocation();
        fetchData();
    };

    const renderCategory = ({ item }) => (
        <TouchableOpacity
            style={styles.catBox}
            onPress={() => navigation.navigate('Categories', { categoryId: item._id })}
        >
            <Image
                source={{
                    uri: `${API_URL.replace('/api', '')}/${item.image}`,
                }}
                style={styles.catIcon}
            />
            <Text style={styles.catText}>{item.name}</Text>
        </TouchableOpacity>
    );

    // Show loading indicator on first load
    if (loading && !refreshing) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={COLORS.primary} />
                    <Text style={styles.loadingText}>Loading services...</Text>
                </View>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView
                showsVerticalScrollIndicator={false}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
            >

                {/* TOP LOCATION HEADER */}
                <View style={styles.locationRow}>
                    <Ionicons name="location" size={22} color="#fff" />
                    <Text style={styles.locationText}>{locationText}</Text>
                </View>

                {/* SEARCH BAR */}
                <View style={styles.searchBox}>
                    <Ionicons name="search" size={20} color="#9CA3AF" />
                    <TextInput
                        placeholder="Search for services..."
                        placeholderTextColor="#9CA3AF"
                        style={styles.searchInput}
                    />
                </View>

                {/* BANNER */}
                {banners.length > 0 ? (
                    <FlatList
                        data={banners}
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        keyExtractor={(item) => item._id}
                        renderItem={({ item }) => (
                            <Image
                                source={{ uri: `${API_URL.replace('/api', '')}/${item.image}` }}
                                style={[styles.banner, { width: 300, marginRight: 10 }]}
                                resizeMode="cover"
                            />
                        )}
                        style={{ marginBottom: 20 }}
                    />
                ) : (
                    <Image
                        source={{ uri: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800&q=80" }}
                        style={styles.banner}
                        defaultSource={require('../../../assets/icon.png')}
                    />
                )}

                {/* ERROR MESSAGE */}
                {error && (
                    <View style={styles.errorContainer}>
                        <Text style={styles.errorText}>⚠️ {error}</Text>
                        <TouchableOpacity onPress={fetchData} style={styles.retryButton}>
                            <Text style={styles.retryText}>Retry</Text>
                        </TouchableOpacity>
                    </View>
                )}

                {/* POPULAR SERVICES TITLE */}
                <Text style={styles.sectionTitle}>Explore All Services</Text>

                <FlatList
                    data={categories}
                    renderItem={renderCategory}
                    keyExtractor={(i) => i._id}
                    numColumns={3}
                    scrollEnabled={false}
                    columnWrapperStyle={{ justifyContent: 'space-between', marginBottom: 14 }}
                />

                {/* RECOMMENDED WORKERS */}
                {workers.length > 0 && (
                    <>
                        <Text style={[styles.sectionTitle, { marginTop: 30 }]}>
                            Recommended Workers
                        </Text>

                        {workers.map((worker) => (
                            <TouchableOpacity
                                key={worker._id}
                                style={styles.workerCard}
                                onPress={() => navigation.navigate('Booking', { workerId: worker._id })}
                            >
                                <Image
                                    source={{
                                        uri: worker.profileImage
                                            ? `${API_URL.replace('/api', '')}/${worker.profileImage}`
                                            : "https://cdn-icons-png.flaticon.com/512/4333/4333609.png"
                                    }}
                                    style={styles.workerImg}
                                />
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.workerName}>
                                        {worker.firstName} {worker.lastName}
                                    </Text>
                                    <Text style={styles.workerRole}>
                                        {worker?.services?.[0]?.category?.name || "Service Provider"}
                                    </Text>
                                </View>

                                <View style={styles.ratingBox}>
                                    <Ionicons name="star" size={14} color={COLORS.primary} />
                                    <Text style={styles.ratingText}>
                                        {worker.rating ? worker.rating.toFixed(1) : "4.5"}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                        ))}
                    </>
                )}

            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.background,
        paddingHorizontal: SPACING.m,
    },

    locationRow: {
        backgroundColor: COLORS.secondary,
        padding: SPACING.m,
        borderRadius: 12,
        flexDirection: "row",
        alignItems: "center",
        marginTop: SPACING.s,
        marginBottom: SPACING.m,
        ...SHADOWS.small,
    },

    locationText: {
        color: COLORS.white,
        fontSize: 16,
        fontWeight: "700",
        marginLeft: SPACING.s,
    },

    searchBox: {
        backgroundColor: COLORS.white,
        paddingHorizontal: SPACING.m,
        paddingVertical: SPACING.s + 4,
        borderRadius: 30,
        flexDirection: "row",
        alignItems: "center",
        marginBottom: SPACING.m,
        borderWidth: 1,
        borderColor: COLORS.border,
        ...SHADOWS.small,
    },

    searchInput: {
        marginLeft: SPACING.s,
        fontSize: 16,
        flex: 1,
        color: COLORS.text,
    },

    banner: {
        width: "100%",
        height: 180,
        borderRadius: 16,
        marginBottom: SPACING.l,
    },

    sectionTitle: {
        fontSize: 18,
        fontWeight: "700",
        color: COLORS.secondary,
        marginBottom: SPACING.m,
        marginTop: SPACING.s
    },

    catBox: {
        width: "31%",
        backgroundColor: COLORS.white,
        alignItems: "center",
        paddingVertical: SPACING.m,
        borderRadius: 16,
        ...SHADOWS.small,
        borderWidth: 1,
        borderColor: COLORS.border,
    },

    catIcon: {
        width: 40,
        height: 40,
        marginBottom: SPACING.s,
        borderRadius: 10,
    },

    catText: {
        fontSize: 13,
        fontWeight: "600",
        textAlign: "center",
        color: COLORS.text,
    },

    workerCard: {
        backgroundColor: COLORS.white,
        padding: SPACING.m,
        borderRadius: 18,
        flexDirection: "row",
        alignItems: "center",
        marginBottom: SPACING.m,
        ...SHADOWS.medium,
        borderWidth: 1,
        borderColor: COLORS.border,
    },

    workerImg: {
        width: 55,
        height: 55,
        borderRadius: 30,
        marginRight: SPACING.m,
        borderWidth: 2,
        borderColor: COLORS.primary,
    },

    workerName: {
        fontSize: 16,
        fontWeight: "700",
        color: COLORS.text,
    },

    workerRole: {
        fontSize: 14,
        color: COLORS.textLight,
    },

    ratingBox: {
        backgroundColor: '#FFFBEB', // Light yellow background for rating
        paddingHorizontal: SPACING.s + 4,
        paddingVertical: SPACING.xs + 2,
        borderRadius: 20,
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: COLORS.primary,
    },

    ratingText: {
        marginLeft: 4,
        fontWeight: "600",
        color: COLORS.text, // Darker text for contrast
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: COLORS.background,
    },
    loadingText: {
        marginTop: SPACING.m,
        fontSize: 16,
        color: COLORS.textLight,
    },
    errorContainer: {
        backgroundColor: '#FEE2E2',
        padding: SPACING.m,
        borderRadius: 12,
        marginBottom: SPACING.m,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    errorText: {
        color: COLORS.error,
        fontSize: 14,
        flex: 1,
    },
    retryButton: {
        backgroundColor: COLORS.error,
        paddingHorizontal: SPACING.m,
        paddingVertical: SPACING.s,
        borderRadius: 8,
    },
    retryText: {
        color: COLORS.white,
        fontWeight: '600',
    },
});

export default HomeScreen;
