import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    Image,
    TextInput,
    RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import api, { API_URL } from '../../services/api';

const CategoriesScreen = ({ navigation, route }) => {
    const [categories, setCategories] = useState([]);
    const [filteredCategories, setFilteredCategories] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState(null);

    useEffect(() => {
        fetchCategories();
    }, []);

    useEffect(() => {
        if (searchTerm) {
            const filtered = categories.filter((cat) =>
                cat.name.toLowerCase().includes(searchTerm.toLowerCase())
            );
            setFilteredCategories(filtered);
        } else {
            setFilteredCategories(categories);
        }
    }, [searchTerm, categories]);

    const fetchCategories = async () => {
        try {
            const response = await api.get('/categories');
            setCategories(response.data);
            setFilteredCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const onRefresh = () => {
        setRefreshing(true);
        fetchCategories();
    };

    const handleCategoryPress = (category) => {
        setSelectedCategory(category);
    };

    const handleSubCategoryPress = (category, subCategory) => {
        navigation.navigate('Booking', {
            categoryId: category._id,
            categoryName: category.name,
            subCategoryId: subCategory._id,
            subCategoryName: subCategory.name,
        });
    };

    const renderCategory = ({ item }) => (
        <TouchableOpacity
            style={styles.categoryCard}
            onPress={() => handleCategoryPress(item)}
        >
            <View style={styles.categoryImageContainer}>
                {item.image ? (
                    <Image
                        source={{ uri: `${API_URL.replace('/api', '')}/${item.image.replace(/\\/g, '/')}` }}
                        style={styles.categoryImage}
                    />
                ) : (
                    <View style={[styles.categoryImage, styles.placeholderImage]}>
                        <Ionicons name="briefcase-outline" size={40} color="#9CA3AF" />
                    </View>
                )}
                <View style={styles.categoryOverlay}>
                    <Text style={styles.categoryName}>{item.name}</Text>
                    <Text style={styles.subCategoryCount}>
                        {item.subCategories?.length || 0} services
                    </Text>
                </View>
            </View>
        </TouchableOpacity>
    );

    const renderSubCategory = ({ item }) => (
        <TouchableOpacity
            style={styles.subCategoryCard}
            onPress={() => handleSubCategoryPress(selectedCategory, item)}
        >
            <View style={styles.subCategoryContent}>
                <Ionicons name="construct-outline" size={24} color="#1E40AF" />
                <View style={styles.subCategoryInfo}>
                    <Text style={styles.subCategoryName}>{item.name}</Text>
                    <Text style={styles.subCategoryDesc}>
                        Professional {item.name.toLowerCase()} services
                    </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
            </View>
        </TouchableOpacity>
    );

    if (selectedCategory) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.header}>
                    <TouchableOpacity
                        style={styles.backButton}
                        onPress={() => setSelectedCategory(null)}
                    >
                        <Ionicons name="arrow-back" size={24} color="#111827" />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>{selectedCategory.name}</Text>
                    <View style={{ width: 40 }} />
                </View>

                <FlatList
                    data={selectedCategory.subCategories}
                    renderItem={renderSubCategory}
                    keyExtractor={(item) => item._id}
                    contentContainerStyle={styles.subCategoryList}
                    ListEmptyComponent={
                        <Text style={styles.emptyText}>No services available</Text>
                    }
                />
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerTitle}>All Services</Text>
            </View>

            <View style={styles.searchContainer}>
                <Ionicons name="search" size={20} color="#9CA3AF" style={styles.searchIcon} />
                <TextInput
                    style={styles.searchInput}
                    placeholder="Search services..."
                    value={searchTerm}
                    onChangeText={setSearchTerm}
                />
                {searchTerm ? (
                    <TouchableOpacity onPress={() => setSearchTerm('')}>
                        <Ionicons name="close-circle" size={20} color="#9CA3AF" />
                    </TouchableOpacity>
                ) : null}
            </View>

            <FlatList
                data={filteredCategories}
                renderItem={renderCategory}
                keyExtractor={(item) => item._id}
                numColumns={2}
                contentContainerStyle={styles.categoryList}
                refreshControl={
                    <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
                }
                ListEmptyComponent={
                    loading ? (
                        <Text style={styles.loadingText}>Loading services...</Text>
                    ) : (
                        <Text style={styles.emptyText}>No services found</Text>
                    )
                }
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F9FAFB',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 16,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#111827',
    },
    backButton: {
        padding: 8,
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        margin: 16,
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#E5E7EB',
    },
    searchIcon: {
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#111827',
    },
    categoryList: {
        padding: 8,
    },
    categoryCard: {
        flex: 1,
        margin: 8,
        borderRadius: 16,
        overflow: 'hidden',
        backgroundColor: 'white',
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
    },
    categoryImageContainer: {
        position: 'relative',
        aspectRatio: 1,
    },
    categoryImage: {
        width: '100%',
        height: '100%',
    },
    placeholderImage: {
        backgroundColor: '#F3F4F6',
        justifyContent: 'center',
        alignItems: 'center',
    },
    categoryOverlay: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        padding: 12,
    },
    categoryName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: 'white',
        marginBottom: 2,
    },
    subCategoryCount: {
        fontSize: 12,
        color: '#E5E7EB',
    },
    subCategoryList: {
        padding: 16,
    },
    subCategoryCard: {
        backgroundColor: 'white',
        borderRadius: 12,
        marginBottom: 12,
        padding: 16,
        elevation: 1,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
    },
    subCategoryContent: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    subCategoryInfo: {
        flex: 1,
        marginLeft: 12,
    },
    subCategoryName: {
        fontSize: 16,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 4,
    },
    subCategoryDesc: {
        fontSize: 14,
        color: '#6B7280',
    },
    loadingText: {
        textAlign: 'center',
        color: '#6B7280',
        padding: 32,
        fontSize: 16,
    },
    emptyText: {
        textAlign: 'center',
        color: '#9CA3AF',
        padding: 32,
        fontSize: 16,
    },
});

export default CategoriesScreen;
