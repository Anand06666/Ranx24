import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';
import api from '../../services/api';

const AddAddressScreen = ({ navigation, route }) => {
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        type: 'home',
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        pincode: '',
        landmark: '',
        isDefault: false,
    });

    const addressTypes = ['home', 'work', 'other'];

    const handleSave = async () => {
        // Validation
        if (!formData.addressLine1.trim()) {
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: 'Address Line 1 is required',
            });
            return;
        }

        if (!formData.city.trim()) {
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: 'City is required',
            });
            return;
        }

        if (!formData.state.trim()) {
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: 'State is required',
            });
            return;
        }

        if (!formData.pincode.trim() || formData.pincode.length !== 6) {
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: 'Please enter a valid 6-digit pincode',
            });
            return;
        }

        try {
            setLoading(true);

            // Ensure boolean values are properly sent
            const addressData = {
                ...formData,
                isDefault: Boolean(formData.isDefault), // Explicitly convert to boolean
            };

            await api.post('/addresses', addressData);

            Toast.show({
                type: 'success',
                text1: 'Success',
                text2: 'Address added successfully',
            });

            navigation.goBack();
        } catch (error) {
            console.error('Error adding address:', error);
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: error.response?.data?.message || 'Failed to add address',
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Add Address</Text>
                <View style={{ width: 24 }} />
            </View>

            <ScrollView style={styles.content}>
                <View style={styles.form}>
                    <Text style={styles.sectionTitle}>Address Type</Text>
                    <View style={styles.typeContainer}>
                        {addressTypes.map((type) => (
                            <TouchableOpacity
                                key={type}
                                style={[
                                    styles.typeButton,
                                    formData.type === type && styles.typeButtonActive,
                                ]}
                                onPress={() => setFormData({ ...formData, type })}
                            >
                                <Ionicons
                                    name={
                                        type === 'home'
                                            ? 'home'
                                            : type === 'work'
                                                ? 'briefcase'
                                                : 'location'
                                    }
                                    size={20}
                                    color={formData.type === type ? '#1E40AF' : '#6B7280'}
                                />
                                <Text
                                    style={[
                                        styles.typeText,
                                        formData.type === type && styles.typeTextActive,
                                    ]}
                                >
                                    {type.charAt(0).toUpperCase() + type.slice(1)}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Address Line 1 *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.addressLine1}
                            onChangeText={(text) =>
                                setFormData({ ...formData, addressLine1: text })
                            }
                            placeholder="House No., Building Name"
                            placeholderTextColor="#9CA3AF"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Address Line 2</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.addressLine2}
                            onChangeText={(text) =>
                                setFormData({ ...formData, addressLine2: text })
                            }
                            placeholder="Road Name, Area, Colony"
                            placeholderTextColor="#9CA3AF"
                        />
                    </View>

                    <View style={styles.row}>
                        <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                            <Text style={styles.label}>City *</Text>
                            <TextInput
                                style={styles.input}
                                value={formData.city}
                                onChangeText={(text) =>
                                    setFormData({ ...formData, city: text })
                                }
                                placeholder="City"
                                placeholderTextColor="#9CA3AF"
                            />
                        </View>

                        <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
                            <Text style={styles.label}>State *</Text>
                            <TextInput
                                style={styles.input}
                                value={formData.state}
                                onChangeText={(text) =>
                                    setFormData({ ...formData, state: text })
                                }
                                placeholder="State"
                                placeholderTextColor="#9CA3AF"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Pincode *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.pincode}
                            onChangeText={(text) =>
                                setFormData({ ...formData, pincode: text })
                            }
                            placeholder="6-digit pincode"
                            placeholderTextColor="#9CA3AF"
                            keyboardType="number-pad"
                            maxLength={6}
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Landmark</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.landmark}
                            onChangeText={(text) =>
                                setFormData({ ...formData, landmark: text })
                            }
                            placeholder="Nearby landmark"
                            placeholderTextColor="#9CA3AF"
                        />
                    </View>

                    <TouchableOpacity
                        style={styles.defaultContainer}
                        onPress={() =>
                            setFormData({ ...formData, isDefault: !formData.isDefault })
                        }
                    >
                        <View style={styles.checkbox}>
                            {formData.isDefault && (
                                <Ionicons name="checkmark" size={16} color="#1E40AF" />
                            )}
                        </View>
                        <Text style={styles.defaultText}>Set as default address</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>

            <View style={styles.footer}>
                <TouchableOpacity
                    style={[styles.saveButton, loading && styles.saveButtonDisabled]}
                    onPress={handleSave}
                    disabled={loading}
                >
                    {loading ? (
                        <ActivityIndicator color="white" />
                    ) : (
                        <Text style={styles.saveButtonText}>Save Address</Text>
                    )}
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F9FAFB',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
    },
    content: {
        flex: 1,
    },
    form: {
        padding: 16,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 12,
    },
    typeContainer: {
        flexDirection: 'row',
        gap: 12,
        marginBottom: 24,
    },
    typeButton: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        paddingVertical: 12,
        borderRadius: 8,
        borderWidth: 2,
        borderColor: '#E5E7EB',
        backgroundColor: 'white',
    },
    typeButtonActive: {
        borderColor: '#1E40AF',
        backgroundColor: '#EFF6FF',
    },
    typeText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#6B7280',
    },
    typeTextActive: {
        color: '#1E40AF',
    },
    inputGroup: {
        marginBottom: 20,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#374151',
        marginBottom: 8,
    },
    input: {
        borderWidth: 1,
        borderColor: '#D1D5DB',
        borderRadius: 8,
        padding: 12,
        fontSize: 16,
        color: '#111827',
        backgroundColor: 'white',
    },
    row: {
        flexDirection: 'row',
    },
    defaultContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 8,
    },
    checkbox: {
        width: 24,
        height: 24,
        borderRadius: 4,
        borderWidth: 2,
        borderColor: '#1E40AF',
        marginRight: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    defaultText: {
        fontSize: 14,
        color: '#374151',
    },
    footer: {
        padding: 16,
        backgroundColor: 'white',
        borderTopWidth: 1,
        borderTopColor: '#E5E7EB',
    },
    saveButton: {
        backgroundColor: '#1E40AF',
        borderRadius: 8,
        padding: 16,
        alignItems: 'center',
    },
    saveButtonDisabled: {
        opacity: 0.6,
    },
    saveButtonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
    },
});

export default AddAddressScreen;
