import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';
import api from '../../services/api';
import { useCart } from '../../context/CartContext';

const CheckoutScreen = ({ navigation, route }) => {
    const { cartItems, clearCart } = useCart();
    const [address, setAddress] = useState('');
    const [phone, setPhone] = useState('');
    const [notes, setNotes] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('cod'); // cod, online
    const [loading, setLoading] = useState(false);

    const calculateTotal = () => {
        return cartItems.reduce(
            (sum, item) => sum + (item.price * item.days || item.price),
            0
        );
    };

    const handlePlaceOrder = async () => {
        if (!address || !phone) {
            Toast.show({
                type: 'error',
                text1: 'Missing Information',
                text2: 'Please provide address and phone number',
            });
            return;
        }

        try {
            setLoading(true);
            const bookingPayload = {
                bookings: cartItems.map(item => {
                    const startDate = new Date();
                    const endDate = new Date();
                    endDate.setDate(startDate.getDate() + item.days);

                    return {
                        workerId: item.workerId,
                        category: item.category,
                        service: item.service,
                        description: '',
                        price: item.price,
                        bookingDate: startDate.toISOString(),
                        bookingTime: "09:00 AM",
                        bookingType: item.bookingType,
                        days: item.days,
                        startDate: startDate.toISOString(),
                        endDate: endDate.toISOString()
                    };
                }),
                address,
                phone,
                notes,
                paymentStatus: 'pending',
                paymentId: paymentMethod === 'online' ? 'dummy_payment_id' : undefined
            };

            const response = await api.post('/bookings/bulk', bookingPayload);

            await clearCart();

            Toast.show({
                type: 'success',
                text1: 'Booking Confirmed!',
                text2: 'Your booking has been placed successfully',
            });

            // Bulk booking returns an array of bookings
            const bookingId = Array.isArray(response.data) ? response.data[0]._id : response.data._id;
            navigation.navigate('OrderSuccess', { bookingId });
        } catch (error) {
            console.error('Error placing order:', error);
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: error.response?.data?.message || 'Failed to place booking',
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity
                    style={styles.backButton}
                    onPress={() => navigation.goBack()}
                >
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Checkout</Text>
                <View style={{ width: 40 }} />
            </View>

            <ScrollView style={styles.content}>
                {/* Cart Items */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Booking Summary</Text>
                    {cartItems.map((item) => (
                        <View key={item._id} style={styles.cartItem}>
                            <View style={styles.itemInfo}>
                                <Text style={styles.itemService}>{item.service}</Text>
                                <Text style={styles.itemWorker}>{item.workerName}</Text>
                                <Text style={styles.itemDetails}>
                                    {item.bookingType} • {item.days} day(s)
                                </Text>
                            </View>
                            <Text style={styles.itemPrice}>₹{item.price * item.days}</Text>
                        </View>
                    ))}
                </View>

                {/* Address */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Service Address</Text>
                    <TextInput
                        style={styles.textArea}
                        placeholder="Enter your complete address"
                        multiline
                        numberOfLines={3}
                        value={address}
                        onChangeText={setAddress}
                    />
                </View>

                {/* Contact */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Contact Number</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter phone number"
                        keyboardType="phone-pad"
                        value={phone}
                        onChangeText={setPhone}
                    />
                </View>

                {/* Notes */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Additional Notes (Optional)</Text>
                    <TextInput
                        style={styles.textArea}
                        placeholder="Any special instructions..."
                        multiline
                        numberOfLines={2}
                        value={notes}
                        onChangeText={setNotes}
                    />
                </View>

                {/* Payment Method */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Payment Method</Text>
                    <TouchableOpacity
                        style={[
                            styles.paymentOption,
                            paymentMethod === 'cod' && styles.paymentOptionActive,
                        ]}
                        onPress={() => setPaymentMethod('cod')}
                    >
                        <View style={styles.paymentOptionLeft}>
                            <Ionicons name="cash-outline" size={24} color="#1E40AF" />
                            <Text style={styles.paymentOptionText}>Cash on Delivery</Text>
                        </View>
                        <Ionicons
                            name={
                                paymentMethod === 'cod'
                                    ? 'radio-button-on'
                                    : 'radio-button-off'
                            }
                            size={24}
                            color="#1E40AF"
                        />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[
                            styles.paymentOption,
                            paymentMethod === 'online' && styles.paymentOptionActive,
                        ]}
                        onPress={() => setPaymentMethod('online')}
                    >
                        <View style={styles.paymentOptionLeft}>
                            <Ionicons name="card-outline" size={24} color="#1E40AF" />
                            <Text style={styles.paymentOptionText}>Online Payment</Text>
                        </View>
                        <Ionicons
                            name={
                                paymentMethod === 'online'
                                    ? 'radio-button-on'
                                    : 'radio-button-off'
                            }
                            size={24}
                            color="#1E40AF"
                        />
                    </TouchableOpacity>
                </View>

                {/* Price Breakdown */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Price Details</Text>
                    <View style={styles.priceRow}>
                        <Text style={styles.priceLabel}>Subtotal</Text>
                        <Text style={styles.priceValue}>₹{calculateTotal()}</Text>
                    </View>
                    <View style={styles.priceRow}>
                        <Text style={styles.priceLabel}>Service Fee</Text>
                        <Text style={styles.priceValue}>₹0</Text>
                    </View>
                    <View style={[styles.priceRow, styles.totalRow]}>
                        <Text style={styles.totalLabel}>Total Amount</Text>
                        <Text style={styles.totalValue}>₹{calculateTotal()}</Text>
                    </View>
                </View>
            </ScrollView>

            <View style={styles.footer}>
                <View style={styles.footerTotal}>
                    <Text style={styles.footerTotalLabel}>Total:</Text>
                    <Text style={styles.footerTotalValue}>₹{calculateTotal()}</Text>
                </View>
                <TouchableOpacity
                    style={[styles.placeOrderButton, loading && styles.buttonDisabled]}
                    onPress={handlePlaceOrder}
                    disabled={loading}
                >
                    <Text style={styles.placeOrderButtonText}>
                        {loading ? 'Placing Order...' : 'Place Order'}
                    </Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F9FAFB',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 16,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
    },
    backButton: {
        padding: 8,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#111827',
    },
    content: {
        flex: 1,
    },
    section: {
        backgroundColor: 'white',
        padding: 16,
        marginTop: 12,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#374151',
        marginBottom: 12,
    },
    cartItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#F3F4F6',
    },
    itemInfo: {
        flex: 1,
    },
    itemService: {
        fontSize: 14,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 4,
    },
    itemWorker: {
        fontSize: 12,
        color: '#6B7280',
        marginBottom: 2,
    },
    itemDetails: {
        fontSize: 12,
        color: '#9CA3AF',
    },
    itemPrice: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#1E40AF',
    },
    input: {
        borderWidth: 1,
        borderColor: '#E5E7EB',
        borderRadius: 8,
        padding: 12,
        fontSize: 14,
    },
    textArea: {
        borderWidth: 1,
        borderColor: '#E5E7EB',
        borderRadius: 8,
        padding: 12,
        fontSize: 14,
        minHeight: 80,
        textAlignVertical: 'top',
    },
    paymentOption: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        borderWidth: 2,
        borderColor: '#E5E7EB',
        borderRadius: 12,
        marginBottom: 12,
    },
    paymentOptionActive: {
        borderColor: '#1E40AF',
        backgroundColor: '#EFF6FF',
    },
    paymentOptionLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
    },
    paymentOptionText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#374151',
    },
    priceRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 8,
    },
    priceLabel: {
        fontSize: 14,
        color: '#6B7280',
    },
    priceValue: {
        fontSize: 14,
        color: '#374151',
    },
    totalRow: {
        borderTopWidth: 1,
        borderTopColor: '#E5E7EB',
        marginTop: 8,
        paddingTop: 12,
    },
    totalLabel: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#111827',
    },
    totalValue: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1E40AF',
    },
    footer: {
        backgroundColor: 'white',
        padding: 16,
        borderTopWidth: 1,
        borderTopColor: '#E5E7EB',
    },
    footerTotal: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 12,
    },
    footerTotalLabel: {
        fontSize: 16,
        fontWeight: '600',
        color: '#374151',
    },
    footerTotalValue: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#1E40AF',
    },
    placeOrderButton: {
        backgroundColor: '#1E40AF',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
    },
    buttonDisabled: {
        opacity: 0.6,
    },
    placeOrderButtonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
    },
});

export default CheckoutScreen;

