import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    RefreshControl,
    ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';
import api from '../../services/api';

const WalletScreen = ({ navigation }) => {
    const [walletData, setWalletData] = useState({
        balance: 0,
        ycCoins: 0,
    });
    const [coinData, setCoinData] = useState({
        balance: 0,
        totalEarned: 0,
        totalSpent: 0,
    });
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    useEffect(() => {
        fetchWalletData();
    }, []);

    const fetchWalletData = async () => {
        try {
            const [walletRes, coinsRes, transactionsRes] = await Promise.all([
                api.get('/wallet/me'),
                api.get('/coins/my-balance'),
                api.get('/wallet/transactions'),
            ]);

            setWalletData({
                balance: walletRes.data.balance || 0,
                ycCoins: walletRes.data.ycCoins || 0,
            });

            setCoinData({
                balance: coinsRes.data.balance || 0,
                totalEarned: coinsRes.data.totalEarned || 0,
                totalSpent: coinsRes.data.totalSpent || 0,
            });

            setTransactions(transactionsRes.data || []);
        } catch (error) {
            console.error('Error fetching wallet data:', error);
            Toast.show({
                type: 'error',
                text1: 'Error',
                text2: 'Failed to load wallet data',
            });
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const getTransactionIcon = (type) => {
        switch (type) {
            case 'credit':
            case 'transfer_in':
            case 'credit_yc':
                return 'arrow-down-circle';
            case 'debit':
            case 'transfer_out':
            case 'redeem_yc':
                return 'arrow-up-circle';
            default:
                return 'swap-horizontal';
        }
    };

    const getTransactionColor = (type) => {
        switch (type) {
            case 'credit':
            case 'transfer_in':
            case 'credit_yc':
                return '#10B981';
            case 'debit':
            case 'transfer_out':
            case 'redeem_yc':
                return '#EF4444';
            default:
                return '#6B7280';
        }
    };

    const renderTransaction = ({ item }) => (
        <View style={styles.transactionCard}>
            <View style={styles.transactionLeft}>
                <View
                    style={[
                        styles.iconContainer,
                        { backgroundColor: `${getTransactionColor(item.type)}20` },
                    ]}
                >
                    <Ionicons
                        name={getTransactionIcon(item.type)}
                        size={24}
                        color={getTransactionColor(item.type)}
                    />
                </View>
                <View>
                    <Text style={styles.transactionDesc}>
                        {item.note || item.type.replace('_', ' ')}
                    </Text>
                    <Text style={styles.transactionDate}>
                        {new Date(item.createdAt || item.date || Date.now()).toLocaleDateString()}
                    </Text>
                </View>
            </View>
            <View>
                {item.amount && (
                    <Text
                        style={[
                            styles.transactionAmount,
                            { color: getTransactionColor(item.type) },
                        ]}
                    >
                        {item.type.includes('credit') || item.type.includes('in') ? '+' : '-'}₹
                        {item.amount}
                    </Text>
                )}
                {item.coinAmount && (
                    <Text style={styles.coinAmount}>
                        {item.coinAmount > 0 ? '+' : ''}
                        {item.coinAmount} YC
                    </Text>
                )}
            </View>
        </View>
    );

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>My Wallet</Text>
                <View style={{ width: 24 }} />
            </View>

            <ScrollView
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={() => {
                            setRefreshing(true);
                            fetchWalletData();
                        }}
                    />
                }
            >
                {/* Wallet Balance Card */}
                <View style={styles.balanceCard}>
                    <Text style={styles.balanceLabel}>Wallet Balance</Text>
                    <Text style={styles.balanceAmount}>₹{walletData.balance.toFixed(2)}</Text>
                    <View style={styles.balanceActions}>
                        <TouchableOpacity
                            style={styles.balanceButton}
                            onPress={() => console.log('Add money')}
                        >
                            <Ionicons name="add-circle-outline" size={20} color="white" />
                            <Text style={styles.balanceButtonText}>Add Money</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.balanceButton, styles.withdrawButton]}
                            onPress={() => console.log('Withdraw')}
                        >
                            <Ionicons name="cash-outline" size={20} color="#1E40AF" />
                            <Text style={[styles.balanceButtonText, { color: '#1E40AF' }]}>
                                Withdraw
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* YCCoins Card */}
                <View style={styles.coinsCard}>
                    <View style={styles.coinsHeader}>
                        <View>
                            <Text style={styles.coinsLabel}>YellowCaps Coins</Text>
                            <Text style={styles.coinsAmount}>{coinData.balance} YC</Text>
                        </View>
                        <View style={styles.coinIcon}>
                            <Ionicons name="star" size={32} color="#F59E0B" />
                        </View>
                    </View>
                    <View style={styles.coinsStats}>
                        <View style={styles.coinStat}>
                            <Text style={styles.coinStatLabel}>Earned</Text>
                            <Text style={styles.coinStatValue}>{coinData.totalEarned}</Text>
                        </View>
                        <View style={styles.coinStat}>
                            <Text style={styles.coinStatLabel}>Spent</Text>
                            <Text style={styles.coinStatValue}>{coinData.totalSpent}</Text>
                        </View>
                    </View>
                    {coinData.balance > 0 && (
                        <TouchableOpacity
                            style={styles.redeemButton}
                            onPress={() => console.log('Redeem coins')}
                        >
                            <Text style={styles.redeemButtonText}>Redeem Coins</Text>
                        </TouchableOpacity>
                    )}
                </View>

                {/* Transactions */}
                <View style={styles.transactionsSection}>
                    <Text style={styles.transactionsTitle}>Transaction History</Text>
                    {transactions.length > 0 ? (
                        transactions.map((item, index) => (
                            <View key={index}>{renderTransaction({ item })}</View>
                        ))
                    ) : (
                        <View style={styles.emptyContainer}>
                            <Ionicons name="wallet-outline" size={60} color="#D1D5DB" />
                            <Text style={styles.emptyText}>No transactions yet</Text>
                        </View>
                    )}
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F9FAFB',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
    },
    balanceCard: {
        backgroundColor: '#1E40AF',
        margin: 16,
        padding: 24,
        borderRadius: 16,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
    },
    balanceLabel: {
        fontSize: 14,
        color: '#BFDBFE',
        marginBottom: 8,
    },
    balanceAmount: {
        fontSize: 36,
        fontWeight: 'bold',
        color: 'white',
        marginBottom: 24,
    },
    balanceActions: {
        flexDirection: 'row',
        gap: 12,
    },
    balanceButton: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        paddingVertical: 12,
        borderRadius: 8,
        gap: 8,
    },
    withdrawButton: {
        backgroundColor: 'white',
    },
    balanceButtonText: {
        color: 'white',
        fontSize: 14,
        fontWeight: '600',
    },
    coinsCard: {
        backgroundColor: 'white',
        marginHorizontal: 16,
        marginBottom: 16,
        padding: 20,
        borderRadius: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 4,
    },
    coinsHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    coinsLabel: {
        fontSize: 14,
        color: '#6B7280',
        marginBottom: 4,
    },
    coinsAmount: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#F59E0B',
    },
    coinIcon: {
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: '#FEF3C7',
        justifyContent: 'center',
        alignItems: 'center',
    },
    coinsStats: {
        flexDirection: 'row',
        gap: 16,
        marginBottom: 16,
    },
    coinStat: {
        flex: 1,
        padding: 12,
        backgroundColor: '#F9FAFB',
        borderRadius: 8,
    },
    coinStatLabel: {
        fontSize: 12,
        color: '#6B7280',
        marginBottom: 4,
    },
    coinStatValue: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
    },
    redeemButton: {
        backgroundColor: '#F59E0B',
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    redeemButtonText: {
        color: 'white',
        fontSize: 14,
        fontWeight: 'bold',
    },
    transactionsSection: {
        padding: 16,
    },
    transactionsTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
        marginBottom: 16,
    },
    transactionCard: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: 'white',
        padding: 16,
        borderRadius: 12,
        marginBottom: 8,
    },
    transactionLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        flex: 1,
    },
    iconContainer: {
        width: 48,
        height: 48,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
    },
    transactionDesc: {
        fontSize: 14,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 4,
        textTransform: 'capitalize',
    },
    transactionDate: {
        fontSize: 12,
        color: '#9CA3AF',
    },
    transactionAmount: {
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'right',
    },
    coinAmount: {
        fontSize: 12,
        color: '#F59E0B',
        fontWeight: '600',
        textAlign: 'right',
        marginTop: 2,
    },
    emptyContainer: {
        alignItems: 'center',
        padding: 48,
    },
    emptyText: {
        fontSize: 16,
        color: '#9CA3AF',
        marginTop: 16,
    },
});

export default WalletScreen;
