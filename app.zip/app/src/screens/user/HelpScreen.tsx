import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

const HelpScreen = ({ navigation }) => {
    const faqs = [
        {
            question: 'How do I book a service?',
            answer: 'Browse categories, select a worker, choose date & time, and confirm booking.',
        },
        {
            question: 'How can I cancel a booking?',
            answer: 'Go to My Bookings, select the booking, and tap Cancel. Refund depends on cancellation policy.',
        },
        {
            question: 'What payment methods are accepted?',
            answer: 'We accept UPI, cards, net banking, and wallet payments.',
        },
        {
            question: 'How do I track my booking?',
            answer: 'Check My Bookings section for real-time status updates.',
        },
    ];

    const handleCall = () => {
        Linking.openURL('tel:+911234567890');
    };

    const handleEmail = () => {
        Linking.openURL('mailto:support@yellowcaps.com');
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Help & Support</Text>
                <View style={{ width: 24 }} />
            </View>

            <ScrollView style={styles.content}>
                <View style={styles.contactSection}>
                    <Text style={styles.sectionTitle}>Contact Us</Text>
                    <TouchableOpacity style={styles.contactCard} onPress={handleCall}>
                        <View style={styles.contactLeft}>
                            <View style={[styles.iconContainer, { backgroundColor: '#DBEAFE' }]}>
                                <Ionicons name="call" size={24} color="#1E40AF" />
                            </View>
                            <View>
                                <Text style={styles.contactLabel}>Call Us</Text>
                                <Text style={styles.contactValue}>+91 123 456 7890</Text>
                            </View>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.contactCard} onPress={handleEmail}>
                        <View style={styles.contactLeft}>
                            <View style={[styles.iconContainer, { backgroundColor: '#FEE2E2' }]}>
                                <Ionicons name="mail" size={24} color="#EF4444" />
                            </View>
                            <View>
                                <Text style={styles.contactLabel}>Email Us</Text>
                                <Text style={styles.contactValue}>support@yellowcaps.com</Text>
                            </View>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
                    </TouchableOpacity>
                </View>

                <View style={styles.faqSection}>
                    <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
                    {faqs.map((faq, index) => (
                        <View key={index} style={styles.faqCard}>
                            <Text style={styles.question}>{faq.question}</Text>
                            <Text style={styles.answer}>{faq.answer}</Text>
                        </View>
                    ))}
                </View>

                <View style={styles.versionSection}>
                    <Text style={styles.versionText}>App Version 1.0.0</Text>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F9FAFB',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
    },
    content: {
        flex: 1,
    },
    contactSection: {
        padding: 16,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#111827',
        marginBottom: 16,
    },
    contactCard: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: 'white',
        padding: 16,
        borderRadius: 12,
        marginBottom: 12,
    },
    contactLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
    },
    iconContainer: {
        width: 48,
        height: 48,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
    },
    contactLabel: {
        fontSize: 12,
        color: '#6B7280',
        marginBottom: 4,
    },
    contactValue: {
        fontSize: 14,
        fontWeight: '600',
        color: '#111827',
    },
    faqSection: {
        padding: 16,
    },
    faqCard: {
        backgroundColor: 'white',
        padding: 16,
        borderRadius: 12,
        marginBottom: 12,
    },
    question: {
        fontSize: 14,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 8,
    },
    answer: {
        fontSize: 14,
        color: '#6B7280',
        lineHeight: 20,
    },
    versionSection: {
        padding: 16,
        alignItems: 'center',
    },
    versionText: {
        fontSize: 12,
        color: '#9CA3AF',
    },
});

export default HelpScreen;
