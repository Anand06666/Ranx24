export const COLORS = {
    primary: '#FFC627', // Yellow from hard hat
    secondary: '#1E3A8A', // Dark Blue from pin/text
    background: '#F3F4F6', // Light Grey
    text: '#1F2937', // Dark Grey
    textLight: '#6B7280', // Light Grey Text
    white: '#FFFFFF',
    black: '#000000',
    error: '#EF4444',
    success: '#10B981',
    warning: '#F59E0B',
    border: '#E5E7EB',
    inputBackground: '#FFFFFF',
    accent: '#3B82F6', // Lighter Blue
};

export const SPACING = {
    xs: 4,
    s: 8,
    m: 16,
    l: 24,
    xl: 32,
    xxl: 40,
};

export const FONTS = {
    regular: 'System', // Replace with custom font if added later
    bold: 'System',
};

export const SHADOWS = {
    small: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
    },
    medium: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 4,
    },
    large: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.15,
        shadowRadius: 8,
        elevation: 8,
    },
};
