import { Platform } from 'react-native';

// Configuration for different environments
const ENV = {
    development: {
        // For Android Emulator: use 10.0.2.2
        // For iOS Simulator: use localhost
        // For Physical Device: use your machine's LAN IP
        API_URL: Platform.select({
            web: 'http://localhost:5000/api',
            android: __DEV__ ? 'http://10.0.2.2:5000/api' : 'http://192.168.1.5:5000/api',
            ios: __DEV__ ? 'http://localhost:5000/api' : 'http://192.168.1.5:5000/api',
            default: 'http://192.168.1.5:5000/api'
        }),
        TIMEOUT: 10000,
        RETRY_ATTEMPTS: 3
    },
    staging: {
        API_URL: 'https://staging-api.yellowcaps.com/api',
        TIMEOUT: 15000,
        RETRY_ATTEMPTS: 2
    },
    production: {
        API_URL: 'https://api.yellowcaps.com/api',
        TIMEOUT: 20000,
        RETRY_ATTEMPTS: 2
    }
};

// Get current environment (default to development)
const getEnvVars = () => {
    // You can change this based on your build configuration
    // For now, always use development
    return ENV.development;
};

const config = getEnvVars();

export default config;

// Helper function to get local network IP (for development)
export const getLocalNetworkIP = () => {
    // This is a placeholder - in production, you'd use a library like 'react-native-network-info'
    // For now, return the configured IP
    return config.API_URL.replace('/api', '').replace('http://', '');
};
