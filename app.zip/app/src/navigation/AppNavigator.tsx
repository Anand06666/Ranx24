import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

// Auth Screens
import OTPLoginScreen from '../screens/auth/OTPLoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';

// User Screens
import HomeScreen from '../screens/user/HomeScreen';
import CategoriesScreen from '../screens/user/CategoriesScreen';
import BookingScreen from '../screens/user/BookingScreen';
import CartScreen from '../screens/user/CartScreen';
import ProfileScreen from '../screens/user/ProfileScreen';
import MyBookingsScreen from '../screens/user/MyBookingsScreen';
import CheckoutScreen from '../screens/user/CheckoutScreen';
import OrderSuccessScreen from '../screens/user/OrderSuccessScreen';
import EditProfileScreen from '../screens/user/EditProfileScreen';
import MyAddressesScreen from '../screens/user/MyAddressesScreen';
import WalletScreen from '../screens/user/WalletScreen';
import HelpScreen from '../screens/user/HelpScreen';
import SettingsScreen from '../screens/user/SettingsScreen';
import AddAddressScreen from '../screens/user/AddAddressScreen';

// Worker Screens
import WorkerDashboardScreen from '../screens/worker/WorkerDashboardScreen';

import { useAuth } from '../context/AuthContext';
import { NavigationParams } from '../types';

const Stack = createStackNavigator<NavigationParams>();
const Tab = createBottomTabNavigator<NavigationParams>();

// Bottom Tab Navigator for User
const UserTabNavigator = () => {
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName: keyof typeof Ionicons.glyphMap;

                    if (route.name === 'Home') {
                        iconName = focused ? 'home' : 'home-outline';
                    } else if (route.name === 'Categories') {
                        iconName = focused ? 'grid' : 'grid-outline';
                    } else if (route.name === 'Cart') {
                        iconName = focused ? 'cart' : 'cart-outline';
                    } else if (route.name === 'Bookings') {
                        iconName = focused ? 'calendar' : 'calendar-outline';
                    } else if (route.name === 'Profile') {
                        iconName = focused ? 'person' : 'person-outline';
                    } else {
                        iconName = 'help-outline';
                    }

                    return <Ionicons name={iconName} size={size} color={color} />;
                },
                tabBarActiveTintColor: '#1E40AF',
                tabBarInactiveTintColor: 'gray',
                headerShown: false,
            })}
        >
            <Tab.Screen name="Home" component={HomeScreen} />
            <Tab.Screen name="Categories" component={CategoriesScreen} />
            <Tab.Screen name="Cart" component={CartScreen} />
            <Tab.Screen name="Bookings" component={MyBookingsScreen} />
            <Tab.Screen name="Profile" component={ProfileScreen} />
        </Tab.Navigator>
    );
};

// Main App Navigator
const AppNavigator: React.FC = () => {
    const { isAuthenticated, loading, user } = useAuth();

    if (loading) {
        return null; // Or a loading screen
    }

    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{ headerShown: false }}>
                {!isAuthenticated ? (
                    // Auth Stack
                    <>
                        <Stack.Screen name="Login" component={OTPLoginScreen} />
                        <Stack.Screen name="Register" component={RegisterScreen} />
                    </>
                ) : user?.role === 'worker' ? (
                    // Worker Stack
                    <Stack.Screen name="WorkerDashboard" component={WorkerDashboardScreen} />
                ) : (
                    // User Stack
                    <>
                        <Stack.Screen name="Main" component={UserTabNavigator} />
                        <Stack.Screen name="Booking" component={BookingScreen} />
                        <Stack.Screen name="Checkout" component={CheckoutScreen} />
                        <Stack.Screen name="OrderSuccess" component={OrderSuccessScreen} />
                        <Stack.Screen name="EditProfile" component={EditProfileScreen} />
                        <Stack.Screen name="MyAddresses" component={MyAddressesScreen} />
                        <Stack.Screen name="Wallet" component={WalletScreen} />
                        <Stack.Screen name="Help" component={HelpScreen} />
                        <Stack.Screen name="Settings" component={SettingsScreen} />
                        <Stack.Screen name="AddAddress" component={AddAddressScreen} />
                    </>
                )}
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default AppNavigator;
